//
// Copyright 2016 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

#import "ScanCaseViewController.h"
#import <ScanditBarcodeScanner/ScanditBarcodeScanner.h>
#import "AppKey.h"

@interface ScanCaseViewController () <SBSScanCaseDelegate>

@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;
@property (nonatomic, strong) SBSScanCase *scanCase;

@end

@implementation ScanCaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Set the license key
    [SBSLicense setAppKey:kScanditBarcodeScannerAppKey];

    // Create ScanCaseSettings and enable some symbologies
    SBSScanCaseSettings *settings = [[SBSScanCaseSettings alloc] init];
    [settings setSymbology:SBSSymbologyEAN13 enabled:YES];
    [settings setSymbology:SBSSymbologyUPC12 enabled:YES];
    [settings setSymbology:SBSSymbologyEAN8 enabled:YES];
    [settings setSymbology:SBSSymbologyUPCE enabled:YES];
    [settings setSymbology:SBSSymbologyCode39 enabled:YES];
    [settings setSymbology:SBSSymbologyITF enabled:YES];
    [settings setSymbology:SBSSymbologyCode128 enabled:YES];
    [settings setSymbology:SBSSymbologyQR enabled:YES];
    [settings setSymbology:SBSSymbologyDatamatrix enabled:YES];

    // Initialize the scan case
    self.scanCase = [SBSScanCase acquireWithSettings:settings delegate:self];

    // Enable the volume button to activate the scanner
    self.scanCase.volumeButtonToScanEnabled = YES;
}

- (IBAction)touchDown:(id)sender {
    // Start scanning when the button is pressed down
    self.scanCase.state = SBSScanCaseStateActive;
}

- (IBAction)touchUp:(id)sender {
    // Pause scanning when the button is released
    // We should pause scanning if the touch ended inside or outside the button,
    // so this method is called by both events (check the storyboard file)
    self.scanCase.state = SBSScanCaseStateStandby;
}

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title
                                                                             message:message
                                                                      preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK"
                                                       style:UIAlertActionStyleDefault
                                                     handler:nil];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

#pragma mark - SBSScanCaseDelegate

- (void)didInitializeScanCase:(SBSScanCase *)scanCase {
    // The scan case is ready to be used.
    // Let's setup a timeout. If the scan case is in idle for more than 30 secs,
    // probably the user is not using the phone, so better save some power and
    // switch the scanner off completely.
    // In order to do that, let's just set a timeout here, then scanCase:didChangeState:reason: will be called
    // and the reason will be SBSScanCaseStateChangeReasonTimeout
    [self.scanCase setTimeout:30 tolerance:5 fromState:SBSScanCaseStateStandby toState:SBSScanCaseStateOff];
}

- (SBSScanCaseState)scanCase:(SBSScanCase *)scanCase
                     didScan:(SBSScanCaseSession *)session {
    // The scanCase:didScan delegate method is invoked from an internal queue. To display
    // the results in the UI, you need to dispatch to the main queue. Note that it's not allowed
    // to use SBSScanCaseSession in the dispatched block as it's only allowed to access the
    // SBSScanCaseSession inside the scanCase:didScan callback. It is however safe to use results
    // returned by session.newlyRecognizedCodes etc.
    SBSCode *code = session.newlyRecognizedCodes.firstObject;
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        self.label.text = [NSString stringWithFormat:@"%@ - %@", code.symbologyName, code.data];
    });

    return SBSScanCaseStateStandby;
}

- (void)scanCase:(SBSScanCase *)scanCase
  didChangeState:(SBSScanCaseState)state
          reason:(SBSScanCaseStateChangeReason)reason {
    // the scanCase:didChangeState:reason: delegate method is invoked from an internal queue. To display
    // the results in the UI, you need to dispatch to the main queue.
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        switch (state) {
            case SBSScanCaseStateStandby:
                self.stateLabel.text = @"StandBy";
                break;
            case SBSScanCaseStateActive:
                self.stateLabel.text = @"Active";
                break;
            case SBSScanCaseStateOff:
                self.stateLabel.text = @"Off";
                if (reason == SBSScanCaseStateChangeReasonTimeout) {
                    // The state changed to SBSScanCaseStateOff because of a timeout.
                    [self showAlertWithTitle:@"Off to save power" message:nil];
                }
                break;
        }
    });
}

@end

//
// Copyright 2018 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

struct Model {
    let color: UIColor
    let stockCount: Int
    let deliveryDate: String
    let code: String
}

extension Model {
    static let dataFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yy"
        return formatter
    }()

    static func mockedModel(for data: String) -> Model {
        return Model(color: mockedColor(for: data),
                     stockCount: mockedStockCount(for: data),
                     deliveryDate: mockedDelivery(for: data),
                     code: data)
    }

    static func mockedColor(for data: String) -> UIColor {
        let suffix = Int(String(data.suffix(1))) ?? 0
        if suffix <= 2 {
            return UIColor.redStockTransparent
        } else if suffix <= 5 {
            return UIColor.greenStockTransparent
        } else {
            return UIColor.yellowStockTransparent
        }
    }

    static func mockedStockCount(for data: String) -> Int {
        let suffix = Int(String(data.suffix(1))) ?? 0
        if suffix <= 2 {
            return suffix % 5 // Critical: 0-5
        } else if suffix <= 5 {
            return 11 + (Int(String(data.suffix(2))) ?? 0) // Good: 11+
        } else {
            return 6 + suffix % 5 // Low: 6-10
        }
    }

    static func mockedDelivery(for data: String) -> String {
        var date = Date()
        if let codeValue = TimeInterval(data) {
            let interval = codeValue.truncatingRemainder(dividingBy: 15) * 3600 * 24
            date.addTimeInterval(interval)
        }
        return Model.dataFormatter.string(from: date)
    }
}

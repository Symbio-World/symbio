//
// Copyright 2018 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit
import ScanditBarcodeScanner.MatrixScan
import ScanditBarcodeScanner

private enum State: Equatable {
    case stopped
    case tracking
    case frozen

    static func ==(_ lhs: State, rhs: State) -> Bool {
        switch (lhs, rhs) {
        case (.stopped, .stopped), (.tracking, .tracking), (.frozen, .frozen): return true
        default: return false
        }
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var freezeButton: UIButton! {
        didSet {
            freezeButton.setBackgroundImage(UIColor.brand.image(), for: .normal)
        }
    }

    private var picker: SBSBarcodePicker!
    private var matrixScanHandler: SBSMatrixScanHandler!
    private var viewBasedOverlay: SBSViewBasedMatrixScanOverlay!
    private var state: State = .stopped {
        didSet {
            switch state {
            case .tracking:
                reset()
                matrixScanHandler.enabled = true
                picker.startScanning(inPausedState: false)
            case .frozen:
                matrixScanHandler.enabled = false
                picker.stopScanning()
            case .stopped: break
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let settings = SBSScanSettings.default()
        settings.setSymbology(.ean13, enabled: true)
        settings.isMatrixScanEnabled = true
        settings.maxNumberOfCodesPerFrame = 15
        settings.highDensityModeEnabled = true
        picker = SBSBarcodePicker(settings: settings)
        picker.overlayController.guiStyle = .none
        matrixScanHandler = SBSMatrixScanHandler(picker: picker)
        matrixScanHandler.delegate = self

        // Add an SBSViewBasedMatrixScanOverlay in order to have custom UIView instances as augmentations.
        viewBasedOverlay = SBSViewBasedMatrixScanOverlay()
        viewBasedOverlay.delegate = self
        matrixScanHandler.addOverlay(viewBasedOverlay)

        // Add an SBSSimpleMatrixScanOverlay in order to highlight the barcodes.
        let simpleOverlay = SBSSimpleMatrixScanOverlay()
        simpleOverlay.delegate = self
        matrixScanHandler.addOverlay(simpleOverlay)

        addChild(picker)
        picker.view.frame = containerView.bounds
        picker.view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        containerView.addSubview(picker.view)
        picker.didMove(toParent: self)

        state = .tracking
    }

    private func computeYOffset(for code: SBSTrackedCode) -> UIOffset {
        let barcodeHeight = computeBarcodeHeight(from: code.predictedLocation)
        let stockViewHeight = StockView.standardHeight
        let stockViewDistance: CGFloat = 8
        let yOffset = -(barcodeHeight / 2 + stockViewHeight / 2 + stockViewDistance)
        return UIOffset(horizontal: 0, vertical: yOffset)
    }

    private func computeBarcodeHeight(from quadrilateral: SBSQuadrilateral) -> CGFloat {
        let topLeft = picker.convertPoint(toPickerCoordinates: quadrilateral.topLeft)
        let bottomLeft = picker.convertPoint(toPickerCoordinates: quadrilateral.bottomLeft)
        let topRight = picker.convertPoint(toPickerCoordinates: quadrilateral.topRight)
        let bottomRight = picker.convertPoint(toPickerCoordinates: quadrilateral.bottomRight)
        return max(bottomLeft.y - topLeft.y, bottomRight.y - topRight.y)
    }

    private func reset() {
        matrixScanHandler.removeAllAugmentations()
    }

    @IBAction func freeze(_ sender: UIButton) {
        switch state {
        case .frozen, .stopped:
            state = .tracking
            freezeButton.setTitle("Freeze", for: .normal)
        case .tracking:
            state = .frozen
            freezeButton.setTitle("Done", for: .normal)
        }
    }
}

extension ViewController: SBSMatrixScanDelegate {
    // This delegate method is called every time a new frame has been processed.
    // In this case we use it to update the offset of the augmentation.
    func matrixScanHandler(_ handler: SBSMatrixScanHandler, didProcessFrame frame: SBSFrame) {
        DispatchQueue.main.async {
            for (identifier, code) in frame.trackedCodes {
                let offset = self.computeYOffset(for: code)
                self.viewBasedOverlay.setOffset(offset, forCodeWithIdentifier: identifier)
            }
        }
    }

    func matrixScanHandler(_ handler: SBSMatrixScanHandler, shouldReject code: SBSTrackedCode) -> Bool {
        return false
    }
}

extension ViewController: SBSViewBasedMatrixScanOverlayDelegate {
    // This delegate method is called every time a new barcode has been tracked.
    // You can implement this method to return the view that will be used as the augmentation.
    func viewBasedMatrixScanOverlay(_ overlay: SBSViewBasedMatrixScanOverlay,
                                    viewFor code: SBSTrackedCode,
                                    withIdentifier identifier: NSNumber) -> UIView {
        guard let data = code.data, let view = Bundle.main.loadNibNamed("StockView", owner: self, options: nil)?.first as? StockView else {
            return UIView()
        }
        let mockedModel = Model.mockedModel(for: data)
        view.model = mockedModel
        view.frame = CGRect(x: 0, y: 0, width: StockView.standardWidth, height: StockView.standardHeight)
        view.delegate = self
        return view
    }

    // This method is called every time a new barcode has been tracked.
    // You can implement this method to return the offset that will be used to position the augmentation
    // with respect to the center of the tracked barcode.
    func viewBasedMatrixScanOverlay(_ overlay: SBSViewBasedMatrixScanOverlay,
                                    offsetFor code: SBSTrackedCode,
                                    withIdentifier identifier: NSNumber) -> UIOffset {
        return computeYOffset(for: code)
    }
}

extension ViewController: StockViewDelegate {
    func didSelect(view: UIView) {
        guard let overlayViewController = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "StockOverlayViewController") as? StockOverlayViewController, let stockView = view as? StockView  else {
            return
        }
        let data = stockView.model?.code
        overlayViewController.code = data
        present(overlayViewController, animated: false, completion: nil)
    }
}

extension ViewController: SBSSimpleMatrixScanOverlayDelegate {
    // This method is called every time a new barcode has been tracked.
    // You can implement this method to customize the color of the highlight.
    func simpleMatrixScanOverlay(_ overlay: SBSSimpleMatrixScanOverlay, colorFor code: SBSTrackedCode, withIdentifier identifier: NSNumber) -> UIColor {
        guard let data = code.data else { return UIColor.clear }
        return Model.mockedColor(for: data)
    }

    // This method is called when the user taps the highlight.
    func simpleMatrixScanOverlay(_ overlay: SBSSimpleMatrixScanOverlay, didTap code: SBSTrackedCode, withIdentifier identifier: NSNumber) {}
}

//
// Copyright 2018 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class StockView: UIView {

    weak var delegate: StockViewDelegate?
    var model: Model? {
        didSet {
            setUp()
        }
    }

    @IBOutlet private var contentView: UIView!
    @IBOutlet private var topStripeView: UIView!
    @IBOutlet private var bottomStripeView: UIView!
    @IBOutlet private var darkView: UIView!
    @IBOutlet private var stockLabel: UILabel!
    @IBOutlet private var stockTextLabel: UILabel!
    @IBOutlet private var deliveryLabel: UILabel!
    @IBOutlet private var viewTip: StockViewTip!

    static let standardWidth: CGFloat = 140
    static let standardHeight: CGFloat = 80

    // MARK: Private Functions

    private func setUp() {
        darkView.layer.cornerRadius = 5.0
        darkView.layer.masksToBounds = true

        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTap))
        contentView.addGestureRecognizer(tapRecognizer)
        updateUI()
    }

    @objc private func didTap() {
        delegate?.didSelect(view: self)
    }

    private func updateUI() {
        guard let model = model else { return }
        // Set view colors
        topStripeView.backgroundColor = model.color
        bottomStripeView.backgroundColor = model.color
        stockTextLabel.textColor = model.color
        viewTip.fillColor = #colorLiteral(red: 0.1450980392, green: 0.1607843137, blue: 0.1607843137, alpha: 0.9)

        stockLabel.text = String(describing: model.stockCount)
        deliveryLabel.text = model.deliveryDate
    }
}

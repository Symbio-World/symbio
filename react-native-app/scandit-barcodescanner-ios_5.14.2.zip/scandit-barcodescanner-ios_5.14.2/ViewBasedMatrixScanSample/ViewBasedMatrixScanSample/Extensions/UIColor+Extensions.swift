//
// Copyright 2018 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

extension UIColor {

    func image() -> UIImage? {
        let rect = CGRect(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        UIGraphicsBeginImageContext(rect.size)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }

        context.setFillColor(self.cgColor)
        context.fill(rect)

        guard let image = UIGraphicsGetImageFromCurrentImageContext() else { return nil }
        UIGraphicsEndImageContext()

        return image
    }

    static var brand: UIColor {
        return UIColor(red: 57 / 255, green: 193 / 255, blue: 204 / 255, alpha: 1)
    }

    static var darkBrand: UIColor {
        return UIColor(red: 50 / 255, green: 135 / 255, blue: 140 / 255, alpha: 1)
    }

    static var greenStock: UIColor {
        return UIColor(red: 57.0/255.0, green: 204.0/255.0, blue: 97.0/255.0, alpha: 1.0)
    }

    static var yellowStock: UIColor {
        return UIColor(red: 250.0/255.0, green: 208.0/255.0, blue: 92.0/255.0, alpha: 1.0)
    }

    static var redStock: UIColor {
        return UIColor(red: 228.0/255.0, green: 76.0/255.0, blue: 76.0/255.0, alpha: 1.0)
    }

    static var greenStockTransparent: UIColor {
        return greenStock.withAlphaComponent(0.6)
    }

    static var yellowStockTransparent: UIColor {
        return yellowStock.withAlphaComponent(0.6)
    }

    static var redStockTransparent: UIColor {
        return redStock.withAlphaComponent(0.6)
    }
}

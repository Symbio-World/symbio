//
// Copyright 2015 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//


#import "SimpleSampleAppDelegate.h"
#import <ScanditBarcodeScanner/ScanditBarcodeScanner.h>
#import "AppKey.h"

@interface SimpleSampleAppDelegate () <SBSScanDelegate, UIAlertViewDelegate>

@property (nonatomic, strong, nullable) SBSBarcodePicker *picker;

@end

@implementation SimpleSampleAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    [SBSLicense setAppKey:kScanditBarcodeScannerAppKey];
    
    // Scandit Barcode Scanner Integration
    // The following method calls illustrate how the Scandit Barcode Scanner can be integrated
    // into your app.
    // Hide the status bar to get a bigger area of the video feed. (optional)
	[[UIApplication sharedApplication] setStatusBarHidden:YES
                                            withAnimation:UIStatusBarAnimationNone];
    
    SBSScanSettings* settings = [SBSScanSettings defaultSettings];
    
    //By default, all symbologies are turned off so you need to explicity enable the desired simbologies.
    NSSet *symbologiesToEnable = [NSSet setWithObjects:
                                                 @(SBSSymbologyEAN13) ,
                                                 @(SBSSymbologyUPC12),
                                                 @(SBSSymbologyEAN8),
                                                 @(SBSSymbologyUPCE),
                                                 @(SBSSymbologyCode39) ,
                                                 @(SBSSymbologyCode128),
                                                 @(SBSSymbologyITF),
                                                 @(SBSSymbologyQR),
                                                 @(SBSSymbologyDatamatrix), nil];
    [settings enableSymbologies:symbologiesToEnable];

    
    // Some 1d barcode symbologies allow you to encode variable-length data. By default, the
    // Scandit BarcodeScanner SDK only scans barcodes in a certain length range. If your
    // application requires scanning of one of these symbologies, and the length is falling
    // outside the default range, you may need to adjust the "active symbol counts" for this
    // symbology. This is shown in the following 3 lines of code.
    
    SBSSymbologySettings *symSettings = [settings settingsForSymbology:SBSSymbologyCode39];
    symSettings.activeSymbolCounts =
        [NSSet setWithObjects:@7, @8, @9, @10, @11, @12, @13, @14, @15, @16, @17, @18, @19, @20, nil];
    // For details on defaults and how to calculate the symbol counts for each symbology, take
    // a look at http://docs.scandit.com/stable/c_api/symbologies.html.
    
    // Initialize the barcode picker - make sure you set the app key above
    self.picker = [[SBSBarcodePicker alloc] initWithSettings:settings];
	
    // only show camera switch button on tablets. For all other devices the switch button is
    // hidden, even if they have a front camera.
	[self.picker.overlayController setCameraSwitchVisibility:SBSCameraSwitchVisibilityOnTablet];
    // set the allowed interface orientations. The value UIInterfaceOrientationMaskAll is the
    // default and is only shown here for completeness.
    [self.picker setAllowedInterfaceOrientations:UIInterfaceOrientationMaskAll];
	// Set the delegate to receive scan event callbacks
	self.picker.scanDelegate = self;
	
    // Open the camera and start scanning barcodes
	[self.picker startScanning];
	
    // Show the barcode picker view
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.window setRootViewController:self.picker];
    [self.window makeKeyAndVisible];

    return YES;
}

//! [SBSScanDelegate callback]
/**
 * This delegate method of the SBSScanDelegate protocol needs to be implemented by
 * every app that uses the Scandit Barcode Scanner and this is where the custom application logic 
 * goes. In the example below, we are just showing an alert view with the result.
 */
- (void)barcodePicker:(SBSBarcodePicker *)thePicker didScan:(SBSScanSession *)session {
	
    // call stopScanning on the session to immediately stop scanning and close the camera. This
    // is the preferred way to stop scanning barcodes from the SBSScanDelegate as it is made sure
    // that no new codes are scanned. When calling stopScanning on the picker, another code may be
    // scanned before stopScanning has completely stoppen the scanning process.
	[session stopScanning];
	
    SBSCode *code = session.newlyRecognizedCodes[0];
    // the barcodePicker:didScan delegate method is invoked from a picker-internal queue. To display
    // the results in the UI, you need to dispatch to the main queue. Note that it's not allowed
    // to use SBSScanSession in the dispatched block as it's only allowed to access the
    // SBSScanSession inside the barcodePicker:didScan callback. It is however safe to use results
    // returned by session.newlyRecognizedCodes etc.
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSString *symbology = code.symbologyName;
        NSString *barcode = code.data;
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:[NSString stringWithFormat:@"Scanned %@", symbology]
                              message:barcode
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];
    });

}

//! [SBSScanDelegate callback]

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	[self.picker startScanning];
}

@end

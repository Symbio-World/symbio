//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        // Provide the license key for your Scandit license.
        SBSLicense.setAppKey(kScanditBarcodeScannerAppKey)

        setUpViewControllers()
        return true
    }

    // Load persistent settings stored on disk.
    lazy var settings: ScanSettings = {
        if let archivedSettings = SettingsArchiver.unarchive() {
            return archivedSettings
        }
        print("\(#file):\(#line) Failed to unarchive settings, falling back to default.")
        return ScanSettings()
    }()

    func setUpViewControllers() {
        // Inject coordinator and settings.
        if let tab = window?.rootViewController as? UITabBarController {
            tab.viewControllers?.forEach { vc in
                if let vc = vc as? ScanViewController {
                    vc.settings = settings
                } else if let nav = vc as? UINavigationController, let vc = nav.viewControllers.first as? MoreExamplesViewController {
                    vc.settings = settings
                    tab.delegate = vc
                } else if let nav = vc as? UINavigationController, let vc = nav.viewControllers.first as? SettingsViewController {
                    vc.coordinator = SettingsCoordinator(viewController: vc, settings: settings)
                }
            }
        }
    }
}

//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation
import SafariServices

class SettingsCoordinator {

    weak var viewController: SettingsViewController?
    var settings: ScanSettings

    init(viewController: SettingsViewController, settings: ScanSettings) {
        self.viewController = viewController
        self.settings = settings
    }

    func present(title: String, selected: Int, options: [String], completion: @escaping (Int) -> Void) {
        guard let navigationController = viewController?.navigationController else { return print("\(#file):\(#line) No navigation controller found") }
        let multipleOption = MultipleOptionTableViewController.from(storyboard: .main)
        multipleOption.title = title
        multipleOption.options = options
        multipleOption.coordinator = self
        multipleOption.completion = completion
        multipleOption.selectedOption = selected
        navigationController.pushViewController(multipleOption, animated: true)
    }

    func present(url: URL) {
        guard let viewController = viewController else { return print("\(#file):\(#line) No view controller found") }
        if #available(iOS 9, *) {
            let safari = SFSafariViewController(url: url)
            viewController.present(safari, animated: true)
        } else {
            UIApplication.shared.openURL(url)
        }
    }

    func select(option index: Int, title: String) {
        settings.set(setting: title, value: index)
    }
}

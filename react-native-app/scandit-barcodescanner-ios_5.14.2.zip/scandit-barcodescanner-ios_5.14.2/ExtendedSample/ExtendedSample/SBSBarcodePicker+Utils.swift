//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

extension SBSBarcodePicker {

    /// Apply the given settings to the overlay controller of the barcode picker.
    ///
    /// - Parameter settings: The overlay settings to be applied.
    func apply(overlaySettings settings: OverlaySettings) {
        // Lock the rotation of the barcode picker.
        allowedInterfaceOrientations = settings.rotationWithDevice ? .all : .portrait
        switch settings.guiStyle {
        case "Frame": overlayController.guiStyle = .default
        case "Laser": overlayController.guiStyle = .laser
        case "None": overlayController.guiStyle = .none
        case "Locations Only": overlayController.guiStyle = .locationsOnly
        default: overlayController.guiStyle = .default
        }
        overlayController.setViewfinderPortrait(width: settings.viewfinderWidth, height: settings.viewfinderHeight)
        overlayController.setViewfinderLandscape(width: settings.viewfinderLandscapeWidth, height: settings.viewfinderLandscapeHeight)
        overlayController.setBeepEnabled(settings.beepEnabled)
        overlayController.setVibrateEnabled(settings.vibrateEnabled)
        overlayController.setTorchEnabled(settings.torchEnabled)
        overlayController.setTorchButton(leftMargin: Float(settings.torchButtonLeftMargin), topMargin: Float(settings.torchButtonTopMargin), width: 40, height: 40)
        overlayController.setCameraSwitchVisibility(SBSCameraSwitchVisibility(rawValue: settings.cameraSwitchVisibility) ?? .never)
        overlayController.setCameraSwitchButton(rightMargin: Float(settings.cameraSwitchButtonRightMargin), topMargin: Float(settings.cameraSwitchButtonTopMargin), width: 40, height: 40)
    }
}

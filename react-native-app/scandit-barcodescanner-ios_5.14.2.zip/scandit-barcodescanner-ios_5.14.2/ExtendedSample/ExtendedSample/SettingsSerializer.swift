//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

// This class is responsible to serialize and deserialize the settings in a JSON format to be later saved in UserDefaults.
class SettingsSerializer {

    static func serialize(_ settings: ScanSettings) -> Data? {
        let symbologies = settings.scan.enabledSymbologies()
        let hasSymbology: (SBSSymbology) -> Bool = { symbologies.contains(NSNumber(value: $0.rawValue)) }
        let qrColorInverted = hasSymbology(.qr) ? settings.scan.settings(for: .qr).colorInvertedEnabled : false
        let microQRColorInverted = hasSymbology(.microQR) ? settings.scan.settings(for: .microQR).colorInvertedEnabled : false
        let datamatrixColorInverted = hasSymbology(.datamatrix) ? settings.scan.settings(for: .datamatrix).colorInvertedEnabled : false
        let dotCodeColorInverted = hasSymbology(.dotCode) ? settings.scan.settings(for: .dotCode).colorInvertedEnabled : false
        let overlay = settings.overlay

        // Create JSON payload.
        let json: [String: Any] = [
            Setting.ean13AndUpc12.string(): hasSymbology(.ean13) || hasSymbology(.upc12),
            Setting.ean8.string(): hasSymbology(.ean8),
            Setting.upce.string(): hasSymbology(.upce),
            Setting.twoDigitAddOn.string(): hasSymbology(.twoDigitAddOn),
            Setting.fiveDigitAddOn.string(): hasSymbology(.fiveDigitAddOn),
            Setting.code11.string(): hasSymbology(.code11),
            Setting.code25.string(): hasSymbology(.code25),
            Setting.code39.string(): hasSymbology(.code39),
            Setting.code93.string(): hasSymbology(.code93),
            Setting.code128.string(): hasSymbology(.code128),
            Setting.itf.string(): hasSymbology(.itf),
            Setting.msiPlessey.string(): hasSymbology(.msiPlessey),
            Setting.gs1Databar.string(): hasSymbology(.gs1Databar),
            Setting.gs1DatabarExpanded.string(): hasSymbology(.gs1DatabarExpanded),
            Setting.gs1DatabarLimited.string(): hasSymbology(.gs1DatabarLimited),
            Setting.codabar.string(): hasSymbology(.codabar),
            Setting.qr.string(): hasSymbology(.qr),
            Setting.microQR.string(): hasSymbology(.microQR),
            Setting.qrColorInverted.string(): qrColorInverted,
            Setting.microQRColorInverted.string(): microQRColorInverted,
            Setting.datamatrix.string(): hasSymbology(.datamatrix),
            Setting.datamatrixColorInverted.string(): datamatrixColorInverted,
            Setting.pdf417.string(): hasSymbology(.pdf417),
            Setting.microPDF417.string(): hasSymbology(.microPDF417),
            Setting.aztec.string(): hasSymbology(.aztec),
            Setting.maxiCode.string(): hasSymbology(.maxiCode),
            Setting.rm4scc.string(): hasSymbology(.rm4scc),
            Setting.kix.string(): hasSymbology(.kix),
            Setting.dotCode.string(): hasSymbology(.dotCode),
            Setting.dotCodeColorInverted.string(): dotCodeColorInverted,
            Setting.code32.string(): hasSymbology(.code32),
            Setting.lapa4sc.string(): hasSymbology(.lapa4sc),

            Setting.rotationWithDevice.string(): overlay.rotationWithDevice,
            Setting.restrictActiveScanningArea.string(): overlay.restrictActiveScanningArea,
            Setting.beepEnabled.string(): overlay.beepEnabled,
            Setting.vibrateEnabled.string(): overlay.vibrateEnabled,
            Setting.torchEnabled.string(): overlay.torchEnabled,

            Setting.timeoutDuration.string(): overlay.timeoutDuration,
            Setting.continuousScanning.string(): overlay.continuousScanning,

            Setting.scanningHotSpotY.string(): overlay.scanningHotSpotY,
            Setting.scanAreaHeight.string(): overlay.scanAreaHeight,
            Setting.scanAreaWidth.string(): overlay.scanAreaWidth,
            Setting.viewfinderWidth.string(): overlay.viewfinderWidth,
            Setting.viewfinderHeight.string(): overlay.viewfinderHeight,
            Setting.viewfinderLandscapeWidth.string(): overlay.viewfinderLandscapeWidth,
            Setting.viewfinderLandscapeHeight.string(): overlay.viewfinderLandscapeHeight,

            Setting.guiStyle.string(): overlay.guiStyle,
            Setting.torchButtonTopMargin.string(): overlay.torchButtonTopMargin,
            Setting.torchButtonLeftMargin.string(): overlay.torchButtonLeftMargin,
            Setting.cameraSwitchVisibility.string(): overlay.cameraSwitchVisibility,
            Setting.cameraSwitchButtonTopMargin.string(): overlay.cameraSwitchButtonTopMargin,
            Setting.cameraSwitchButtonRightMargin.string(): overlay.cameraSwitchButtonRightMargin,
            Setting.cameraResolution.string(): settings.scan.highDensityModeEnabled 
            ]
        return try? JSONSerialization.data(withJSONObject: json, options: [])
    }

    static func deserialize(_ data: Data) -> ScanSettings? {
        guard let json = try? JSONSerialization.jsonObject(with: data, options: []), let dictionary = json as? JSON else { return nil }
        return ScanSettings(dictionary: dictionary)
    }
}

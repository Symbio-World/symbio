//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class ScanViewController: UIViewController {

    // The barcode picker that is displayed on the screen.
    // It must be lazily initialized so that the AppDelegate can first set the API key.
    lazy var barcodePicker: SBSBarcodePicker = {
        let picker = SBSBarcodePicker(settings: self.settings.scan)
        picker.apply(overlaySettings: self.settings.overlay)
        picker.scanDelegate = self
        picker.processFrameDelegate = self
        return picker
    }()

    // Custom view controller used to display the barcode results.
    lazy var barcodeResult: BarcodeResultViewController = {
        return BarcodeResultViewController.from(storyboard: .main)
    }()

    lazy var scanModeOverlay: ScanModeOverlayViewController = {
        let scanModeOverlay = ScanModeOverlayViewController.from(storyboard: .main)
        scanModeOverlay.delegate = self
        return scanModeOverlay
    }()

    // Settings injected from `AppDelegate.swift` so they are easily accessible.
    var settings: ScanSettings!

    var scanTimer: Timer?
    var lastScannedDate: Date?
    var scanStartedDate = Date()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Add the barcode picker as child view controller displaying in full screen.
        addChild(barcodePicker)
        barcodePicker.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barcodePicker.view)
        barcodePicker.view.constrainToEdges(of: view)
        barcodePicker.didMove(toParent: self)

        // Add our barcode result view controller that will display the results and set it to hidden.
        addChild(barcodeResult)
        barcodeResult.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barcodeResult.view)
        barcodeResult.view.constrainToEdges(of: view)
        barcodeResult.view.isHidden = true
        barcodeResult.didMove(toParent: self)

        addChild(scanModeOverlay)
        scanModeOverlay.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scanModeOverlay.view)
        scanModeOverlay.view.constrainToEdges(of: view)
        scanModeOverlay.view.isHidden = true
        scanModeOverlay.didMove(toParent: self)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        // Apply scan settings selected by the user.
        barcodePicker.apply(settings.scan)

        // Apply overlay settings selected by the user.
        barcodePicker.apply(overlaySettings: settings.overlay)

        // Start scanning.
        barcodePicker.startScanning()
        barcodeResult.continuousMode = settings.overlay.continuousScanning
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        // It's a good idea to pause scanning and turn off the torch when the view disappears to clean the resources as soon as possible.
        barcodePicker.pauseScanning()
        barcodePicker.switchTorch(on: false)

        // Hide the result view.
        barcodeResult.view.isHidden = true
        scanModeOverlay.view.isHidden = true
    }

    // Hide the status bar to have the barcode picker in full screen.
    override var prefersStatusBarHidden: Bool {
        return true
    }
}

// MARK: - SBSScanDelegate

extension ScanViewController: SBSScanDelegate {
    // This delegate method of the SBSScanDelegate protocol needs to be implemented by
    // every app that uses the Scandit Barcode Scanner and this is where the custom application logic
    // goes. In the example below, we are presenting a custom view with the code information that can
    // be dismissed with a simple touch.
    func barcodePicker(_ picker: SBSBarcodePicker, didScan session: SBSScanSession) {
        // Store the newly recognized codes.
        let codes = session.newlyRecognizedCodes
        lastScannedDate = Date()
        // Pause scanning to present the newly found code.
        picker.pauseScanning()

        // Present view on main queue and pass the codes data.
        DispatchQueue.main.async {

            // Pass the codes to display them and set completion handler to resume scanning when the overlay view is dismissed.
            self.barcodeResult.show(codes: codes) { [weak self] in
                guard let strongSelf = self, let parent = strongSelf.parent as? UITabBarController else { return }
                if parent.selectedViewController === strongSelf {
                    picker.resumeScanning()
                    strongSelf.scanStartedDate = Date()
                }
            }
            self.view.bringSubviewToFront(self.barcodeResult.view)
        }
    }
}

extension ScanViewController: SBSProcessFrameDelegate {
    func barcodePicker(_ barcodePicker: SBSBarcodePicker, didProcessFrame frame: CMSampleBuffer, session: SBSScanSession) {
        let codes = session.newlyRecognizedCodes
        if codes.count == 0, settings.overlay.timeoutDuration > 0.0 {
            let lastScannedOrScanStartedDate = scanStartedDate
            let timeoutTimeInterval = TimeInterval(settings.overlay.timeoutDuration)
            let currentDate = Date()
            let delta = currentDate.timeIntervalSince(lastScannedOrScanStartedDate)
            if  delta > timeoutTimeInterval {
                scanModeOverlay.show()
                barcodePicker.pauseScanning()
            }
        }
    }

}

extension ScanViewController: ScanModeOverlayDelegate {
    func didTap() {
        scanModeOverlay.hide()
        barcodePicker.resumeScanning()
        scanStartedDate = Date()
    }
}

//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

// Define all possible settings that have to be saved.
enum Setting: String {
    // Bool
    case rotationWithDevice = "Rotation with device"
    case ean13AndUpc12 = "EAN-13 & UPC-12"
    case ean8 = "EAN-8"
    case upce = "UPC-E"
    case twoDigitAddOn = "Two-Digit-Add-On"
    case fiveDigitAddOn = "Five-Digit-Add-On"
    case code11 = "Code 11"
    case code25 = "Code 25"
    case code39 = "Code 39"
    case code93 = "Code 93"
    case code128 = "Code 128"
    case itf = "Interleaved-Two-of-Five (ITF)"
    case msiPlessey = "MSI Plessey"
    case gs1Databar = "GS1 DataBar"
    case gs1DatabarExpanded = "GS1 DataBar Expanded"
    case gs1DatabarLimited = "GS1 DataBar Limited"
    case codabar = "Codabar"
    case qr = "QR Code"
    case microQR = "Micro QR Code"
    case qrColorInverted = "Color-Inverted QR Code"
    case microQRColorInverted = "Color-Inverted Micro QR Code"
    case datamatrix = "Data Matrix"
    case datamatrixColorInverted = "Color-Inverted Data Matrix"
    case dpmMode = "DPM Data Matrix"
    case pdf417 = "PDF417"
    case microPDF417 = "MicroPDF417"
    case aztec = "Aztec Code"
    case maxiCode = "MaxiCode"
    case rm4scc = "RM4SCC"
    case kix = "KIX"
    case dotCode = "GS1 DotCode"
    case dotCodeColorInverted = "Color-Inverted GS1 DotCode"
    case code32 = "Code 32 (Italian Pharma Code)"
    case lapa4sc = "Posti LAPA (Lajittelupalvelu) 4 State Code"
    case restrictActiveScanningArea = "Restrict Scanning Area"
    case beepEnabled = "Beep"
    case vibrateEnabled = "Vibrate"
    case torchEnabled = "Torch Button Visible"
    case continuousScanning = "Continuous Scanning"

    // Float
    case scanningHotSpotY = "Hot Spot Y"
    case scanAreaHeight = "Scan Area Height"
    case scanAreaWidth = "Scan Area Width"
    case viewfinderWidth = "Width (Portrait)"
    case viewfinderHeight = "Height (Portrait)"
    case viewfinderLandscapeWidth = "Width (Landscape)"
    case viewfinderLandscapeHeight = "Height (Landscape)"
    case timeoutDuration = "Timeout duration"

    // String
    case guiStyle = "GUI Style"
    case cameraResolution = "Resolution"

    // Int
    case torchButtonLeftMargin = "Torch Left Margin"
    case torchButtonTopMargin = "Torch Top Margin"
    case cameraSwitchVisibility = "Camera Switch Button Visible"
    case cameraSwitchButtonRightMargin = "Camera Switch Right Margin"
    case cameraSwitchButtonTopMargin = "Camera Switch Top Margin"
}

extension Setting {
    func string() -> String {
        return self.rawValue
    }
}

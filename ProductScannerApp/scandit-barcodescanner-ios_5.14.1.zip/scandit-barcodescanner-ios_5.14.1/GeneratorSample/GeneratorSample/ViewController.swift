//
// Copyright 2018 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit
import ScanditBarcodeScanner

typealias Color = [Int]

class ViewController: UIViewController {
    @IBOutlet weak var inputField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var resultImageView: UIImageView!

    let picker = SBSBarcodePicker(settings: SBSScanSettings.default())
    
    var selectedSymbology: SBSSymbology = symbologies[SBSSymbology.qr.description]! {
        didSet {
            generate(for: inputField.text)
            inputField.resignFirstResponder()
            if selectedSymbology == .itf {
                inputField.keyboardType = .numberPad
            } else {
                inputField.keyboardType = .default
            }
        }
    }

    var selectedForegroundColor: [Int] = colors["Black"]! {
        didSet {
            generate(for: inputField.text)
        }
    }

    var selectedBackgroundColor: [Int] = colors["White"]! {
        didSet {
            generate(for: inputField.text)
        }
    }

    static let symbologies: [String: SBSSymbology] = [
        SBSSymbology.qr.description: .qr,
        SBSSymbology.datamatrix.description: .datamatrix,
        SBSSymbology.code128.description: .code128,
        SBSSymbology.code39.description: .code39,
        SBSSymbology.itf.description: .itf
    ]

    static let colors: [String: Color] = [
        "White": [255, 255, 255, 255],
        "Black": [0, 0, 0, 255],
        "Scandit Blue": [46, 192, 204, 255],
        "Grey": [210, 210, 210, 255],
        "Red": [255, 0, 0, 255]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(textFieldValueDidChange),
                                               name: UITextField.textDidChangeNotification,
                                               object: inputField)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    @IBAction func textFieldValueDidChange() {
        generate(for: inputField.text)
    }

    @objc private func generate(for input: String?) {
        guard let input = input, input.count > 0 else { return }
        do {
            // Instantiate the barcode generator object.
            let generator = try picker.barcodeGenerator(for: selectedSymbology)

            // Set the foreground and the background colors
            var options = [
                "foregroundColor": selectedForegroundColor,
                "backgroundColor": selectedBackgroundColor,
                ] as [String : Any]
            
            // If code39 or ITF, unitSize should be 2, instead of 1.
            if selectedSymbology == .code39 || selectedSymbology == .itf {
                options["unitSize"] = 2
            }
            try generator.setOptions(options)

            // Generate the barcode image.
            let result = try generator.generate(from: input)

            if selectedSymbology == .code128 || selectedSymbology == .code39 || selectedSymbology == .itf {
                resultImageView.contentMode = .scaleToFill
            } else {
                resultImageView.contentMode = .scaleAspectFit
            }

            // To properly scale up the resulting image, we need to use the nearest neighbor interpolation filter.
            resultImageView.layer.magnificationFilter = .nearest
            resultImageView.layer.minificationFilter = .nearest
            resultImageView.image = result
        } catch let error {
            // If something went wrong when generating the barcode, details can be found in the error.
            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: String(describing: UITableViewCell.self))
        if cell == nil {
            cell = UITableViewCell(style: .value1, reuseIdentifier: String(describing: UITableViewCell.self))
        }
        switch indexPath.row {
        case 0:
            cell?.textLabel?.text = "Selected symbology"
            cell?.detailTextLabel?.text = selectedSymbology.description
        case 1:
            let index = ViewController.colors.values.firstIndex(of: selectedForegroundColor)!
            let colorName: String = ViewController.colors.keys[index]
            cell?.textLabel?.text = "Selected foreground color"
            cell?.detailTextLabel?.text = colorName
        case 2:
            let index = ViewController.colors.values.firstIndex(of: selectedBackgroundColor)!
            let colorName: String = ViewController.colors.keys[index]
            cell?.textLabel?.text = "Selected background color"
            cell?.detailTextLabel?.text = colorName
        default:
            break
        }
        return cell!
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        var title = ""
        var actions = [UIAlertAction]()
        switch indexPath.row {
        case 0:
            title = "Select symbology"
            for (key, value) in ViewController.symbologies {
                let action = UIAlertAction(title: key, style: .default) { [weak self] (_) in
                    self?.selectedSymbology = value
                    self?.tableView.reloadData()
                }
                actions.append(action)
            }
        case 1:
            title = "Select foreground color"
            for (key, value) in ViewController.colors {
                let action = UIAlertAction(title: key, style: .default) { [weak self] (_) in
                    self?.selectedForegroundColor = value
                    self?.tableView.reloadData()
                }
                actions.append(action)
            }
        case 2:
            title = "Select background color"
            for (key, value) in ViewController.colors {
                let action = UIAlertAction(title: key, style: .default) { [weak self] (_) in
                    self?.selectedBackgroundColor = value
                    self?.tableView.reloadData()
                }
                actions.append(action)
            }
        default:
            return
        }
        let alert = UIAlertController(title: title, message: nil, preferredStyle: .actionSheet)
        actions.forEach {
            alert.addAction($0)
        }
        present(alert, animated: true, completion: nil)
    }
}

extension SBSSymbology: CustomStringConvertible {
    public var description: String {
        switch self {
        case .datamatrix: return "Data Matrix"
        case .qr: return "QR Code"
        case .code128: return "Code 128"
        case .code39: return "Code 39"
        case .itf: return "ITF"
        default: return "Not supported"
        }
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

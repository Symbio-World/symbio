//-----------------------------------------------------------------------------
//
//  main.m
//
//-----------------------------------------------------------------------------

#import <UIKit/UIKit.h>

#import "SimpleSampleAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SimpleSampleAppDelegate class]));
    }
}
															 

//
//  SplitViewResultTableViewController.swift
//  UseCases
//
//  Created by Franciszek Gonciarz on 26.03.2018.
//  Copyright © 2018 Scandit AG. All rights reserved.
//

import UIKit

class SplitViewResultTableViewController: UIViewController {

    @IBOutlet weak var splitViewResultsTableView: UITableView!

    var splitViewResults: [SplitViewResult] = []
    var openedInSeparateViewController = false

    override func viewDidLoad() {
        super.viewDidLoad()
        splitViewResultsTableView.reloadData()
        if openedInSeparateViewController {
            populateTableView(with: splitViewResults)
        }
    }

    func add(result: SplitViewResult) {
        splitViewResults.insert(result, at: 0)
        splitViewResultsTableView.beginUpdates()
        splitViewResultsTableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .top)
        splitViewResultsTableView.endUpdates()
    }

    func populateTableView(with results: [SplitViewResult]) {
        splitViewResults = results
        splitViewResultsTableView.reloadData()
    }

    func clearResults() {
        splitViewResults = []
        splitViewResultsTableView.reloadData()
    }

}

extension SplitViewResultTableViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return splitViewResults.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SplitViewResultTableViewCell") as! SplitViewResultTableViewCell

        cell.barcodeLabel.text = splitViewResults[indexPath.row].barcode
        cell.symbologyLabel.text = splitViewResults[indexPath.row].symbology
        cell.symbologyLabel.textColor = UIColor.darkGray

        return cell
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

}

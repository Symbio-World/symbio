//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class BarcodeResultViewController: UIViewController {

    @IBOutlet weak var scannedCodesLabel: UILabel!
    @IBOutlet weak var barcodeTextView: UITextView!

    var continuousMode = false {
        didSet {
            view.isUserInteractionEnabled = !continuousMode
        }
    }

    var completion: (() -> Void)?

    func continuousModeAction() {
        commonDismiss(0.5)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.7)
        view.isHidden = true
        view.alpha = 0.0
    }

    func show(codes: [SBSCode], completion: @escaping () -> Void) {
        self.completion = completion
        // Build string to show all codes in the UITextView.
        scannedCodesLabel.text = codes.count == 1 ? "Scanned Code" : "Scanned Codes"
        var result = ""
        codes.forEach { code in
            let data = code.data ?? ""
            result += "\n\(code.symbologyName)\n\(data)\n"
        }
        barcodeTextView.text = result

        view.isHidden = false
        UIView.animate(withDuration: 0.2, animations: {
            self.view.alpha = 1.0
        }) { _ in
            if self.continuousMode {
                self.commonDismiss(0.5)
            }
        }
    }

    @IBAction func dismiss(_ sender: UITapGestureRecognizer) {
        commonDismiss(0.2)
    }

    private func commonDismiss(_ duration: TimeInterval) {
        UIView.animate(withDuration: duration, animations: {
            self.view.alpha = 0.0
        }) { _ in
            self.view.isHidden = true
            self.completion?()
        }
    }
}

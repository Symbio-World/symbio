//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class SettingsDataSource: NSObject {

    struct ButtonTitle {
        static let openDocumentation = "Open the online documentation"
        static let resetDefault = "Reset to Default"
    }

    lazy var dataSource: [[SettingsTableViewCell]] = {
        return self.loadDataSource()
    }()

    let dataSourceTitles = ["General Configuration", "Barcode Decoder Configuration", "Scanning Area", "Scan Mode", "Viewfinder", "Feedback", "Button Visibility", "Camera", ""]
    let coordinator: SettingsCoordinator
    var settings: ScanSettings {
        return coordinator.settings
    }

    var dpmModeEnabled: Bool {
        let settings = self.settings.scan.settings(for: .datamatrix)
        let extensionEnabled = settings.enabledExtensions.contains("direct_part_marking_mode")
        let restrictedScanningModeEnabled = self.settings.scan.restrictedAreaScanningEnabled
        let dpmModeScanningArea = CGRect(x: 0, y: 0, width: 0.33, height: 0.33)
        let dpmModeScanningAreaIsActive = (
            dpmModeScanningArea == self.settings.scan.activeScanningAreaLandscape &&
                dpmModeScanningArea == self.settings.scan.activeScanningAreaPortrait
        )
        return extensionEnabled && restrictedScanningModeEnabled && dpmModeScanningAreaIsActive
    }

    func hasSymbology(_ symbology: SBSSymbology) -> Bool {
        return settings.scan.enabledSymbologies().contains(NSNumber(value: symbology.rawValue))
    }

    init(coordinator: SettingsCoordinator) {
        self.coordinator = coordinator
        super.init()
    }

    func switchChanged(cell: TableViewSwitchCell) {
        guard let text = cell.textLabel?.text else { return }
        coordinator.settings.set(setting: text, value: cell.switcher.isOn)
        dataSource = loadDataSource()
        // Check if we have to insert/remove any row.
        switch text {
        case Setting.restrictActiveScanningArea.string():
            let rows = (1...3).map { IndexPath(row: $0, section: 2) }
            if coordinator.settings.overlay.restrictActiveScanningArea {
                coordinator.viewController?.tableView.insertRows(at: rows, with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: rows, with: .fade)
            }
        case Setting.torchEnabled.string():
            let rows = (1...2).map { IndexPath(row: $0, section: 6) }
            if coordinator.settings.overlay.torchEnabled {
                coordinator.viewController?.tableView.insertRows(at: rows, with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: rows, with: .fade)
            }
        case Setting.datamatrix.string():
            let indexPaths: [IndexPath] = (8...9).map { IndexPath(row: $0, section: 1) }
            if cell.switcher.isOn {
                coordinator.viewController?.tableView.insertRows(at: indexPaths, with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: indexPaths, with: .fade)
            }
        case Setting.dotCode.string():
            let desiredIndex = hasSymbology(.datamatrix) ? 17 : 15
            let indexPath = IndexPath(row: desiredIndex, section: 1)
            if cell.switcher.isOn {
                coordinator.viewController?.tableView.insertRows(at: [indexPath], with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: [indexPath], with: .fade)
            }
        case Setting.microQR.string():
            var desiredIndex = hasSymbology(.datamatrix) ? 22 : 20
            desiredIndex = hasSymbology(.dotCode) ? desiredIndex + 1 : desiredIndex
            let indexPath = IndexPath(row: desiredIndex, section: 1)
            if cell.switcher.isOn {
                coordinator.viewController?.tableView.insertRows(at: [indexPath], with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: [indexPath], with: .fade)
            }
        case Setting.qr.string():
            var desiredIndex = hasSymbology(.datamatrix) ? 25 : 23
            desiredIndex = hasSymbology(.dotCode) ? desiredIndex + 1 : desiredIndex
            desiredIndex = hasSymbology(.microQR) ? desiredIndex + 1 : desiredIndex
            let indexPath = IndexPath(row: desiredIndex, section: 1)
            if cell.switcher.isOn {
                coordinator.viewController?.tableView.insertRows(at: [indexPath], with: .fade)
            } else {
                coordinator.viewController?.tableView.deleteRows(at: [indexPath], with: .fade)
            }
        default:
            break
        }
    }

    func sliderChanged(cell: TableViewSliderCell) {
        if let text = cell.label.text {
            settings.set(setting: text, value: cell.slider.value)
        }
        dataSource = loadDataSource()
    }

    private func loadDataSource() -> [[SettingsTableViewCell]] {
        var localdatasource: [[SettingsTableViewCell]] = [
            [
                .switch(title: Setting.rotationWithDevice.string(), value: settings.overlay.rotationWithDevice)
            ],
            [
                .switch(title: Setting.aztec.string(), value: hasSymbology(.aztec)),
                .switch(title: Setting.codabar.string(), value: hasSymbology(.codabar)),
                .switch(title: Setting.code11.string(), value: hasSymbology(.code11)),
                .switch(title: Setting.code25.string(), value: hasSymbology(.code25)),
                .switch(title: Setting.code32.string(), value: hasSymbology(.code32)),
                .switch(title: Setting.code39.string(), value: hasSymbology(.code39)),
                .switch(title: Setting.code93.string(), value: hasSymbology(.code93)),
                .switch(title: Setting.datamatrix.string(), value: hasSymbology(.datamatrix)),
                .switch(title: Setting.ean13AndUpc12.string(), value: hasSymbology(.ean13)),
                .switch(title: Setting.ean8.string(), value: hasSymbology(.ean8)),
                .switch(title: Setting.fiveDigitAddOn.string(), value: hasSymbology(.fiveDigitAddOn)),
                .switch(title: Setting.gs1Databar.string(), value: hasSymbology(.gs1Databar)),
                .switch(title: Setting.gs1DatabarExpanded.string(), value: hasSymbology(.gs1DatabarExpanded)),
                .switch(title: Setting.gs1DatabarLimited.string(), value: hasSymbology(.gs1DatabarLimited)),
                .switch(title: Setting.dotCode.string(), value: hasSymbology(.dotCode)),
                .switch(title: Setting.itf.string(), value: hasSymbology(.itf)),
                .switch(title: Setting.kix.string(), value: hasSymbology(.kix)),
                .switch(title: Setting.msiPlessey.string(), value: hasSymbology(.msiPlessey)),
                .switch(title: Setting.maxiCode.string(), value: hasSymbology(.maxiCode)),
                .switch(title: Setting.microQR.string(), value: hasSymbology(.microQR)),
                .switch(title: Setting.microPDF417.string(), value: hasSymbology(.microPDF417)),
                .switch(title: Setting.pdf417.string(), value: hasSymbology(.pdf417)),
                .switch(title: Setting.qr.string(), value: hasSymbology(.qr)),
                .switch(title: Setting.rm4scc.string(), value: hasSymbology(.rm4scc)),
                .switch(title: Setting.twoDigitAddOn.string(), value: hasSymbology(.twoDigitAddOn)),
                .switch(title: Setting.upce.string(), value: hasSymbology(.upce)),
                .switch(title: Setting.lapa4sc.string(), value: hasSymbology(.lapa4sc))
            ],
            [
                .switch(title: Setting.restrictActiveScanningArea.string(), value: settings.overlay.restrictActiveScanningArea),
                .slider(title: Setting.scanAreaWidth.string(), value: settings.overlay.scanAreaWidth, minimum: 0.0, maximum: 1.0),
                .slider(title: Setting.scanAreaHeight.string(), value: settings.overlay.scanAreaHeight, minimum: 0.0, maximum: 1.0),
                .slider(title: Setting.scanningHotSpotY.string(), value: settings.overlay.scanningHotSpotY, minimum: 0.0, maximum: 1.0)
            ],
            [
                .slider(title: Setting.timeoutDuration.string(), value: settings.overlay.timeoutDuration, minimum: 0.0, maximum: 10.0),
                .switch(title: Setting.continuousScanning.string(), value: settings.overlay.continuousScanning)
            ],
            [
                .option(title: Setting.guiStyle.string(), selected: guiStyleSelected(settings.overlay.guiStyle), values: ["Frame", "Laser", "None", "Locations Only"]),
                .slider(title: Setting.viewfinderWidth.string(), value: settings.overlay.viewfinderWidth, minimum: 0.05, maximum: 1.0),
                .slider(title: Setting.viewfinderLandscapeWidth.string(), value: settings.overlay.viewfinderLandscapeWidth, minimum: 0.05, maximum: 1.0),
                .slider(title: Setting.viewfinderHeight.string(), value: settings.overlay.viewfinderHeight, minimum: 0.05, maximum: 1.0),
                .slider(title: Setting.viewfinderLandscapeHeight.string(), value: settings.overlay.viewfinderLandscapeHeight, minimum: 0.05, maximum: 1.0)
            ],
            [
                .switch(title: Setting.beepEnabled.string(), value: settings.overlay.beepEnabled),
                .switch(title: Setting.vibrateEnabled.string(), value: settings.overlay.vibrateEnabled)
            ],
            [
                .switch(title: Setting.torchEnabled.string(), value: settings.overlay.torchEnabled),
                .slider(title: Setting.torchButtonLeftMargin.string(), value: settings.overlay.torchButtonLeftMargin, minimum: 0.0, maximum: 50.0),
                .slider(title: Setting.torchButtonTopMargin.string(), value: settings.overlay.torchButtonTopMargin, minimum: 0.0, maximum: 50.0),
                .option(title: Setting.cameraSwitchVisibility.string(), selected: settings.overlay.cameraSwitchVisibility, values: ["Never", "Only on tablet", "Always"]),
                .slider(title: Setting.cameraSwitchButtonRightMargin.string(), value: settings.overlay.cameraSwitchButtonRightMargin, minimum: 0.0, maximum: 50.0),
                .slider(title: Setting.cameraSwitchButtonTopMargin.string(), value: settings.overlay.cameraSwitchButtonTopMargin, minimum: 0.0, maximum: 50.0)
            ],
            [
                .option(title: Setting.cameraResolution.string(), selected: cameraResolutionSelected(settings.scan.highDensityModeEnabled), values: ["HD (720p)","Full HD (1080p)"]),
            ],
            [
                .button(title: ButtonTitle.openDocumentation, link: URL(string: "http://docs.scandit.com")),
                .button(title: ButtonTitle.resetDefault, link: nil)
            ],
        ]
        if hasSymbology(.datamatrix) {
            let dataMatrixColorInverted = settings.scan.settings(for: .datamatrix).colorInvertedEnabled
            localdatasource[1].insert(SettingsTableViewCell.switch(title: Setting.datamatrixColorInverted.string(), value: dataMatrixColorInverted), at: 8)
            localdatasource[1].insert(SettingsTableViewCell.switch(title: Setting.dpmMode.string(), value: dpmModeEnabled), at: 9)
        }
        if (hasSymbology(.dotCode)) {
            let desiredIndex = hasSymbology(.datamatrix) ? 17 : 15
            let dotCodeColorInverted = hasSymbology(.dotCode) ? settings.scan.settings(for: .dotCode).colorInvertedEnabled : false
            localdatasource[1].insert(SettingsTableViewCell.switch(title: Setting.dotCodeColorInverted.string(), value: dotCodeColorInverted), at: desiredIndex)
        }
        if (hasSymbology(.microQR)) {
            var desiredIndex = hasSymbology(.datamatrix) ? 22 : 20
            desiredIndex = hasSymbology(.dotCode) ? desiredIndex + 1 : desiredIndex
            let microQRColorInverted = hasSymbology(.microQR) ? settings.scan.settings(for: .microQR).colorInvertedEnabled : false
            localdatasource[1].insert(SettingsTableViewCell.switch(title: Setting.microQRColorInverted.string(), value: microQRColorInverted), at: desiredIndex)
        }
        if (hasSymbology(.qr)) {
            var desiredIndex = hasSymbology(.datamatrix) ? 25 : 23
            desiredIndex = hasSymbology(.dotCode) ? desiredIndex + 1 : desiredIndex
            desiredIndex = hasSymbology(.microQR) ? desiredIndex + 1 : desiredIndex
            let qrColorInverted = hasSymbology(.qr) ? settings.scan.settings(for: .qr).colorInvertedEnabled : false
            localdatasource[1].insert(SettingsTableViewCell.switch(title: Setting.qrColorInverted.string(), value: qrColorInverted), at: desiredIndex)
        }
        return localdatasource
    }

    private func guiStyleSelected(_ guiStyle: String) -> Int {
        switch guiStyle {
        case "Frame":
            return 0
        case "Laser":
            return 1
        case "None":
            return 2
        case "Locations Only":
            return 3
        default:
            return 0
        }
    }
    
    private func cameraResolutionSelected(_ useHighDensityMode: Bool) -> Int {
        return useHighDensityMode ? 1 : 0
    }
    
}

// MARK: - UITableViewDataSource

extension SettingsDataSource: UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return dataSource.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionData = dataSource[section]
        // Configuration of 'Restrict Scanning Area' section.
        if let first = sectionData.first, section == 2, case let .switch(_, value) = first, value == false {
            return 1
        } else if section == 4 {
            // Configuration of the 'Viewfinder' section.
            if case let SettingsTableViewCell.option(_, selected, _) = sectionData[0], selected == 0 {
                return 5
            } else if case let SettingsTableViewCell.option(_, selected, _) = sectionData[0], selected == 1 {
                return 3
            } else {
                return 1
            }
        } else if section == 6, sectionData.count > 3 {
            // Configuration of the 'Viewfinder' section.
            var rows = 2
            if case let SettingsTableViewCell.switch(_, value) = sectionData[0], value {
                rows += 2
            }
            if case let SettingsTableViewCell.option(_, selected, _) = sectionData[3], selected == 1 || selected == 2 {
                rows += 2
            }
            return rows
        }
        return dataSource[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Check section 5 configuration and display cells accordingly.
        if indexPath.section == 6 {
            // If the first setting is off, we don't to show the next two rows and instead proceed with the next option.
            if indexPath.row == 1, case let SettingsTableViewCell.switch(_, value) = dataSource[6][0],
                case let SettingsTableViewCell.option(title, selected, values) = dataSource[6][3],
                value == false {
                let cell: TableViewOptionCell = tableView.dequeueReusableCell(for: indexPath)
                cell.textLabel?.text = title
                cell.detailTextLabel?.text = values[selected]
                return cell
            } else if indexPath.row == 2, case let SettingsTableViewCell.switch(_, value) = dataSource[6][0],
                case let SettingsTableViewCell.slider(title, sliderValue, minimum, maximum) = dataSource[6][4],
                value == false {
                let cell: TableViewSliderCell = tableView.dequeueReusableCell(for: indexPath)
                cell.label.text = title
                cell.setSlider(value: sliderValue, minimum: minimum, maximum: maximum)
                cell.sliderHandler = { [weak self] in
                    guard let strongSelf = self else { return }
                    strongSelf.sliderChanged(cell: cell)
                }
                return cell
            } else if indexPath.row == 3, case let SettingsTableViewCell.switch(_, value) = dataSource[6][0],
                case let SettingsTableViewCell.slider(title, sliderValue, minimum, maximum) = dataSource[6][5],
                value == false {
                let cell: TableViewSliderCell = tableView.dequeueReusableCell(for: indexPath)
                cell.label.text = title
                cell.setSlider(value: sliderValue, minimum: minimum, maximum: maximum)
                cell.sliderHandler = { [weak self] in
                    guard let strongSelf = self else { return }
                    strongSelf.sliderChanged(cell: cell)
                }
                return cell
            }
        } else if indexPath.section == 4 {
            if indexPath.row == 0, case let SettingsTableViewCell.option(_, selected, _) = dataSource[3][0] {
                if selected == 1 {
                    // Show width in portrait.
                    if indexPath.row == 1, case let SettingsTableViewCell.slider(title, value, minimum, maximum) = dataSource[3][1] {
                        let cell: TableViewSliderCell = tableView.dequeueReusableCell(for: indexPath)
                        cell.label.text = title
                        cell.setSlider(value: value, minimum: minimum, maximum: maximum)
                        cell.sliderHandler = { [weak self] in
                            guard let strongSelf = self else { return }
                            strongSelf.sliderChanged(cell: cell)
                        }
                        return cell
                    } else if indexPath.row == 2, case let SettingsTableViewCell.slider(title, value, minimum, maximum) = dataSource[3][3] {
                        // Show width in landscape.
                        let cell: TableViewSliderCell = tableView.dequeueReusableCell(for: indexPath)
                        cell.label.text = title
                        cell.setSlider(value: value, minimum: minimum, maximum: maximum)
                        cell.sliderHandler = { [weak self] in
                            guard let strongSelf = self else { return }
                            strongSelf.sliderChanged(cell: cell)
                        }
                        return cell
                    }
                }
            }
        }
        // Use the standard data source to figure out what to display.
        let cellType = dataSource[indexPath.section][indexPath.row]
        switch cellType {
        case .slider(let title, let value, let minimum, let maximum):
            let cell: TableViewSliderCell = tableView.dequeueReusableCell(for: indexPath)
            cell.label.text = title
            cell.setSlider(value: value, minimum: minimum, maximum: maximum)
            cell.sliderHandler = { [weak self] in
                guard let strongSelf = self else { return }
                strongSelf.sliderChanged(cell: cell)
            }
            return cell
        case .switch(let title, let value):
            let cell: TableViewSwitchCell = tableView.dequeueReusableCell(for: indexPath)
            cell.textLabel?.text = title
            cell.switcher.isOn = value
            cell.switchHandler = { [weak self] in
                guard let strongSelf = self else { return }
                strongSelf.switchChanged(cell: cell)
            }
            return cell
        case .option(let title, let selected, let values):
            let cell: TableViewOptionCell = tableView.dequeueReusableCell(for: indexPath)
            cell.textLabel?.text = title
            cell.detailTextLabel?.text = values[selected]
            return cell
        case .button(let title, _):
            let cell: TableViewButtonCell = tableView.dequeueReusableCell(for: indexPath)
            cell.textLabel?.text = title
            return cell
        }
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dataSourceTitles[section]
    }
}

// MARK: - UITableViewDelegate

extension SettingsDataSource: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Internal utility functions.
        func insertRows(from: Int, to: Int, section: Int) {
            let rows = (from...to).map { IndexPath(row: $0, section: section) }
            tableView.insertRows(at: rows, with: .fade)
        }
        func deleteRows(from: Int, to: Int, section: Int) {
            let rows = (from...to).map { IndexPath(row: $0, section: section) }
            tableView.deleteRows(at: rows, with: .fade)
        }

        // If a row in section 6 is selected, figure out which cells to display depending on the selected configuration.
        if indexPath.section == 6, indexPath.row == 1, case let SettingsTableViewCell.switch(_, value) = dataSource[6][0],
            case let SettingsTableViewCell.option(title, selected, values) = dataSource[6][3],
            value == false {
            coordinator.present(title: title, selected: selected, options: values) { newSelected in
                if newSelected != selected {
                    self.dataSource = self.loadDataSource()
                    if title == Setting.cameraSwitchVisibility.string() {
                        if self.coordinator.settings.overlay.cameraSwitchVisibility != 0, tableView.numberOfRows(inSection: 6) < 4 {
                            insertRows(from: 2, to: 3, section: 6)
                        } else if self.coordinator.settings.overlay.cameraSwitchVisibility == 0, tableView.numberOfRows(inSection: 6) > 2 {
                            deleteRows(from: 2, to: 3, section: 6)
                        }
                    }
                    tableView.reloadRows(at: [indexPath], with: .automatic)
                }
            }
            return
        }

        // We are in no special configuration, so we can use the default data source to figure out what to do.
        let type = dataSource[indexPath.section][indexPath.row]
        if case .button(let title, let url) = type {
            if title == ButtonTitle.resetDefault {
                // Reset settings to default
                coordinator.settings.resetToDefault()
                dataSource = loadDataSource()
                tableView.reloadData()
                tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
            } else if title == ButtonTitle.openDocumentation, let url = url {
                coordinator.present(url: url)
            }
            tableView.deselectRow(at: indexPath, animated: true)
        } else if case .option(let title, let selected, let values) = type {
            // Present multiple options view controller and register callback to apply the selected option later.
            coordinator.present(title: title, selected: selected, options: values) { newSelected in
                if newSelected != selected {
                    self.dataSource = self.loadDataSource()
                    if title == Setting.cameraSwitchVisibility.string() {
                        if self.coordinator.settings.overlay.cameraSwitchVisibility != 0, tableView.numberOfRows(inSection: 6) < 5 {
                            insertRows(from: 4, to: 5, section: 6)
                        } else if self.coordinator.settings.overlay.cameraSwitchVisibility == 0, tableView.numberOfRows(inSection: 6) > 2 {
                            deleteRows(from: 4, to: 5, section: 6)
                        }
                    } else if title == Setting.guiStyle.string() {
                        // Show width and height slider when choosing 'frame' as the GUI style.
                        if newSelected == 0 {
                            if selected == 1 {
                                // Only insert two rows.
                                insertRows(from: 3, to: 4, section: 4)
                            } else {
                                // Insert 4 rows.
                                insertRows(from: 1, to: 4, section: 4)
                            }
                        } else if newSelected == 1 {
                            // Only show the width slider when choosing 'laser' as the GUI style.
                            if selected == 0 {
                                // Delete two rows.
                                deleteRows(from: 3, to: 4, section: 4)
                            } else {
                                // Add two rows
                                insertRows(from: 1, to: 2, section: 4)
                            }
                        } else {
                            // We had rows before and now we need to delete them.
                            let lastToBeDeleted = tableView.numberOfRows(inSection: 4) - 1
                            if lastToBeDeleted > 1 {
                                deleteRows(from: 1, to: lastToBeDeleted, section: 4)
                            }
                        }
                    }
                    tableView.reloadRows(at: [indexPath], with: .automatic)
                }
            }
        }
    }
}

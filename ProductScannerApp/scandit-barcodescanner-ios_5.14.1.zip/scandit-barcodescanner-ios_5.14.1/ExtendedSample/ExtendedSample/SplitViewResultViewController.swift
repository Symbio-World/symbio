//
//  SplitViewResultViewController.swift
//  UseCases
//
//  Created by Franciszek Gonciarz on 27.03.2018.
//  Copyright © 2018 Scandit AG. All rights reserved.
//

import UIKit

class SplitViewResultViewController: UIViewController {

    @IBOutlet weak var resultTableViewContainer: UIView!
    @IBOutlet weak var clearButton: UIButton!

    private var splitViewResultTableViewController: SplitViewResultTableViewController?
    var splitViewResults: [SplitViewResult] = []
    var splitViewResultViewControllerDelegate: SplitViewResultViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Results"
        configureButtons()
    }

    func configureButtons() {
        clearButton.setBackgroundImage(UIColor.standardBlue.image(), for: .normal)
        clearButton.tintColor = UIColor.standardBlue
        clearButton.clipsToBounds = true
        clearButton.layer.cornerRadius = 5
        let rightBarButton = UIBarButtonItem(title: "Close", style: .plain, target: self, action: #selector(close))
        let leftBarButton = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.rightBarButtonItem = rightBarButton
        navigationItem.backBarButtonItem = leftBarButton
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EmbedSplitViewResultTableViewController" {
            splitViewResultTableViewController = segue.destination as? SplitViewResultTableViewController
            splitViewResultTableViewController?.splitViewResults = splitViewResults
            splitViewResultTableViewController?.openedInSeparateViewController = true
        }
    }

    @IBAction func clearButtonPressed(_ sender: Any) {
        splitViewResultTableViewController?.clearResults()
        splitViewResultViewControllerDelegate?.onResultsCleared()

    }

    @objc private func close() {
        _ = navigationController?.popToRootViewController(animated: true)
    }

}

//
//  SBSScanSettings+SampleDefault.swift
//  ExtendedSample
//
//  Created by Luca Torella on 27.07.17.
//  Copyright © 2017 Patrick Balestra. All rights reserved.
//

import Foundation

extension SBSScanSettings {
    static var sampleDefault: SBSScanSettings {
        let settings = SBSScanSettings.default()
        let symbologies: [SBSSymbology] = [.ean13, .upc12, .ean8, .upce, .code39, .code128, .itf, .qr, .datamatrix]
        for symbology in symbologies {
            settings.setSymbology(symbology, enabled: true)
        }
        return settings
    }
}

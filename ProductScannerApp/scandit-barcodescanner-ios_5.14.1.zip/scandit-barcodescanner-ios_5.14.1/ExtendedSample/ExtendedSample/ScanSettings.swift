//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

typealias JSON = [String: Any]

class ScanSettings {

    // Initialize the scan settings to default. They can be modified via the Settings view controller by the user.
    private(set) var scan = SBSScanSettings.sampleDefault
    // Initialize the overlay settings to default. They can be modified via the Settings view controller by the user.
    private(set) var overlay = OverlaySettings.default()

    init(dictionary: JSON = [:]) {
        applySettings(from: dictionary)
    }

    // Apply a setting change to the overally representation and saves it to disk.
    func set<T>(setting: String, value: T) {
        // Apply new setting.
        applySettings(from: [setting: value])
        // Save on disk.
        SettingsArchiver.archive(settings: self)
    }

    private func applySettings(from dictionary: JSON) {

        // Always prefer the backward facing camera over front-facing camera.
        scan.cameraFacingPreference = .back

        // Enable the selected 1D symbologies.
        if let ean13AndUpc12: Bool = dictionary.value(key: Setting.ean13AndUpc12.string()) {
            scan.setSymbology(.ean13, enabled: ean13AndUpc12)
            scan.setSymbology(.upc12, enabled: ean13AndUpc12)
        }
        if let ean8: Bool = dictionary.value(key: Setting.ean8.string()) {
            scan.setSymbology(.ean8, enabled: ean8)
        }
        if let upce: Bool = dictionary.value(key: Setting.upce.string()) {
            scan.setSymbology(.upce, enabled: upce)
        }
        if let twoDigitAddOn: Bool = dictionary.value(key: Setting.twoDigitAddOn.string()) {
            scan.setSymbology(.twoDigitAddOn, enabled: twoDigitAddOn)
        }
        if let fiveDigitAddOn: Bool = dictionary.value(key: Setting.fiveDigitAddOn.string()) {
            scan.setSymbology(.fiveDigitAddOn, enabled: fiveDigitAddOn)
        }
        if let code11: Bool = dictionary.value(key: Setting.code11.string()) {
            scan.setSymbology(.code11, enabled: code11)
        }
        if let code25: Bool = dictionary.value(key: Setting.code25.string()) {
            scan.setSymbology(.code25, enabled: code25)
        }
        if let code39: Bool = dictionary.value(key: Setting.code39.string()) {
            scan.setSymbology(.code39, enabled: code39)
        }
        if let code93: Bool = dictionary.value(key: Setting.code93.string()) {
            scan.setSymbology(.code93, enabled: code93)
        }
        if let code128: Bool = dictionary.value(key: Setting.code128.string()) {
            if !code128 {
                scan.settings(for: .code128).colorInvertedEnabled = false
            }
            scan.setSymbology(.code128, enabled: code128)
        }
        if let itf: Bool = dictionary.value(key: Setting.itf.string()) {
            scan.setSymbology(.itf, enabled: itf)
        }
        if let msiPlessey: Bool = dictionary.value(key: Setting.msiPlessey.string()) {
            scan.setSymbology(.msiPlessey, enabled: msiPlessey)
        }
        if let gs1Databar: Bool = dictionary.value(key: Setting.gs1Databar.string()) {
            scan.setSymbology(.gs1Databar, enabled: gs1Databar)
        }
        if let gs1DatabarExpanded: Bool = dictionary.value(key: Setting.gs1DatabarExpanded.string()) {
            scan.setSymbology(.gs1DatabarExpanded, enabled: gs1DatabarExpanded)
        }
        if let gs1DatabarLimited: Bool = dictionary.value(key: Setting.gs1DatabarLimited.string()) {
            scan.setSymbology(.gs1DatabarLimited, enabled: gs1DatabarLimited)
        }
        if let codabar: Bool = dictionary.value(key: Setting.codabar.string()) {
            scan.setSymbology(.codabar, enabled: codabar)
        }
        if let code32: Bool = dictionary.value(key: Setting.code32.string()) {
            scan.setSymbology(.code32, enabled: code32)
        }
        if let lapa4sc: Bool = dictionary.value(key: Setting.lapa4sc.string()) {
            scan.setSymbology(.lapa4sc, enabled: lapa4sc)
        }

        // Enable the selected 2D symbologies.
        if let qr: Bool = dictionary.value(key: Setting.qr.string()) {
            if !qr {
                scan.settings(for: .qr).colorInvertedEnabled = false
            }
            scan.setSymbology(.qr, enabled: qr)
        }
        if let microQR: Bool = dictionary.value(key: Setting.microQR.string()) {
            if !microQR {
                scan.settings(for: .microQR).colorInvertedEnabled = false
            }
            scan.setSymbology(.microQR, enabled: microQR)
        }
        if let datamatrix: Bool = dictionary.value(key: Setting.datamatrix.string()) {
            scan.setSymbology(.datamatrix, enabled: datamatrix)
            if !datamatrix {
                applySettings(from: [Setting.dpmMode.string(): false])
            }
        }
        if let pdf417: Bool = dictionary.value(key: Setting.pdf417.string()) {
            scan.setSymbology(.pdf417, enabled: pdf417)
        }
        if let microPDF417: Bool = dictionary.value(key: Setting.microPDF417.string()) {
            scan.setSymbology(.microPDF417, enabled: microPDF417)
        }
        if let aztec: Bool = dictionary.value(key: Setting.aztec.string()) {
            scan.setSymbology(.aztec, enabled: aztec)
        }
        if let maxiCode: Bool = dictionary.value(key: Setting.maxiCode.string()) {
            scan.setSymbology(.maxiCode, enabled: maxiCode)
        }

        // Enable the selected postal code symbologies.
        if let rm4scc: Bool = dictionary.value(key: Setting.rm4scc.string()) {
            scan.setSymbology(.rm4scc, enabled: rm4scc)
        }
        if let kix: Bool = dictionary.value(key: Setting.kix.string()) {
            scan.setSymbology(.kix, enabled: kix)
        }
        if let dotCode: Bool = dictionary.value(key: Setting.dotCode.string()) {
            if !dotCode {
                scan.settings(for: .dotCode).colorInvertedEnabled = false
            }
            scan.setSymbology(.dotCode, enabled: dotCode)
        }

        if let value: Bool = dictionary.value(key: Setting.restrictActiveScanningArea.string()) {
            overlay.restrictActiveScanningArea = value
        }
        if overlay.restrictActiveScanningArea {
            let width: Float = dictionary.value(key: Setting.scanAreaWidth.string()) ?? overlay.scanAreaWidth
            let height: Float = dictionary.value(key: Setting.scanAreaHeight.string()) ?? overlay.scanAreaHeight
            let scanningHotSpotY: Float = dictionary.value(key: Setting.scanningHotSpotY.string()) ?? overlay.scanningHotSpotY

            overlay.scanAreaWidth = width
            overlay.scanAreaHeight = height
            overlay.scanningHotSpotY = scanningHotSpotY
            scan.scanningHotSpot = CGPoint(x: 0.5, y: CGFloat(scanningHotSpotY))
            scan.setActiveScanningArea(CGRect(x: 0.5 - width / 2, y: scanningHotSpotY, width: width, height: height))
        } else {
            let defaultSettings = SBSScanSettings.default()
            var scanArea: CGRect
            if (overlay.rotationWithDevice) {
                scanArea = UIDevice.current.orientation.isLandscape ? defaultSettings.activeScanningAreaLandscape : defaultSettings.activeScanningAreaPortrait
            } else {
                scanArea = defaultSettings.activeScanningAreaPortrait
            }
            scan.scanningHotSpot = defaultSettings.scanningHotSpot
            scan.setActiveScanningArea(scanArea)
        }
        if let datamatrixColorInverted: Bool = dictionary.value(key: Setting.datamatrixColorInverted.string()) {
            let datamatrixSettings = scan.settings(for: .datamatrix)
            datamatrixSettings.colorInvertedEnabled = datamatrixColorInverted
        }
        if let dpmMode: Bool = dictionary.value(key: Setting.dpmMode.string()) {
            let scanArea = dpmMode ? CGRect(x: 0, y: 0, width: 0.33, height: 0.33) : CGRect(x: 0, y: 0, width: 1, height: 1)
            scan.activeScanningAreaPortrait = scanArea
            scan.activeScanningAreaLandscape = scanArea
            // It is recommended to restrict the scanning area to a smaller part of the image for best performance.
            scan.restrictedAreaScanningEnabled = dpmMode
            // Enabling the direct_part_marking_mode extension comes at the cost of increased frame processing times.
            scan.settings(for: .datamatrix).setExtension("direct_part_marking_mode", enabled: dpmMode)
        }
        if let qrColorInverted: Bool = dictionary.value(key: Setting.qrColorInverted.string()), qrColorInverted {
            let qrSettings = scan.settings(for: .qr)
            qrSettings.colorInvertedEnabled = qrColorInverted
        }
        if let microQRColorInverted: Bool = dictionary.value(key: Setting.microQRColorInverted.string()), microQRColorInverted {
            let microQRSettings = scan.settings(for: .microQR)
            microQRSettings.colorInvertedEnabled = microQRColorInverted
        }
        if let dotCodeInverted: Bool = dictionary.value(key: Setting.dotCodeColorInverted.string()), dotCodeInverted {
            let dotCodeSettings = scan.settings(for: .dotCode)
            dotCodeSettings.colorInvertedEnabled = dotCodeInverted
        }
        if let _: Bool = dictionary.value(key: Setting.twoDigitAddOn.string())  {
            scan.maxNumberOfCodesPerFrame = max(2, scan.maxNumberOfCodesPerFrame)
        } else if let _: Bool = dictionary.value(key: Setting.fiveDigitAddOn.string()) {
            scan.maxNumberOfCodesPerFrame = max(2, scan.maxNumberOfCodesPerFrame)
        }

        // Overlay controller settings.
        if let value: Bool = dictionary.value(key: Setting.rotationWithDevice.string()) {
            overlay.rotationWithDevice = value
        }
        if let value: Int = dictionary.value(key: Setting.guiStyle.string()) {
            switch value {
            case 0:
                overlay.guiStyle = "Frame"
            case 1:
                overlay.guiStyle = "Laser"
            case 2:
                overlay.guiStyle = "None"
            case 3:
                overlay.guiStyle = "Locations Only"
            default:
                fatalError("GUI Style selected out of bounds")
            }
        }
        if let value: Int = dictionary.value(key: Setting.cameraResolution.string()) {
            switch value {
            case 0:
                scan.highDensityModeEnabled = false
            case 1:
                scan.highDensityModeEnabled = true
            default:
                scan.highDensityModeEnabled = false
            }
        }
        if let value: Float = dictionary.value(key: Setting.viewfinderWidth.string()) {
            overlay.viewfinderWidth = value
        }
        if let value: Float = dictionary.value(key: Setting.viewfinderHeight.string()) {
            overlay.viewfinderHeight = value
        }
        if let value: Float = dictionary.value(key: Setting.viewfinderLandscapeWidth.string()) {
            overlay.viewfinderLandscapeWidth = value
        }
        if let value: Float = dictionary.value(key: Setting.viewfinderLandscapeHeight.string()) {
            overlay.viewfinderLandscapeHeight = value
        }
        if let value: Bool = dictionary.value(key: Setting.beepEnabled.string()) {
            overlay.beepEnabled = value
        }
        if let value: Bool = dictionary.value(key: Setting.vibrateEnabled.string()) {
            overlay.vibrateEnabled = value
        }
        if let value: Bool = dictionary.value(key: Setting.torchEnabled.string()) {
            overlay.torchEnabled = value
        }
        if let value: Float = dictionary.value(key: Setting.torchButtonTopMargin.string()) {
            overlay.torchButtonTopMargin = value
        }
        if let value: Float = dictionary.value(key: Setting.torchButtonLeftMargin.string()) {
            overlay.torchButtonLeftMargin = value
        }
        if let value: Int = dictionary.value(key: Setting.cameraSwitchVisibility.string()) {
            overlay.cameraSwitchVisibility = value
        }
        if let value: Float = dictionary.value(key: Setting.cameraSwitchButtonTopMargin.string()) {
            overlay.cameraSwitchButtonTopMargin = value
        }
        if let value: Float = dictionary.value(key: Setting.cameraSwitchButtonRightMargin.string()) {
            overlay.cameraSwitchButtonRightMargin = value
        }
        if let value: Float = dictionary.value(key: Setting.timeoutDuration.string()) {
            overlay.timeoutDuration = value
        }
        if let value: Bool = dictionary.value(key: Setting.continuousScanning.string()) {
            overlay.continuousScanning = value
        }
    }

    // Reset all settings to their default values.
    func resetToDefault() {
        overlay = OverlaySettings.default()
        scan = SBSScanSettings.sampleDefault
    }
}

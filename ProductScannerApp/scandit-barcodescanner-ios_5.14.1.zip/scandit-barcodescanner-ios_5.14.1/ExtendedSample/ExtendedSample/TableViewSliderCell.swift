//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class TableViewSliderCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    @IBOutlet weak var slider: UISlider!

    var hasIntValue = false
    var sliderHandler: (() -> Void)?

    func setSlider(value: Float, minimum: Float, maximum: Float) {
        needsIntValue()
        slider.minimumValue = minimum
        slider.maximumValue = maximum
        slider.value = value
        set(value: slider.value)
    }

    @IBAction func valueChanged(_ slider: UISlider) {
        set(value: slider.value)
        sliderHandler?()
    }

    private func set(value: Float) {
        if hasIntValue {
            valueLabel.text = "\(Int(value))"
        } else {
            valueLabel.text = String.localizedStringWithFormat("%.2f", value)
        }
    }

    private func needsIntValue() {
        if let title = label?.text, title == Setting.torchButtonTopMargin.string() || title == Setting.torchButtonLeftMargin.string() || title == Setting.cameraSwitchButtonTopMargin.string() || title == Setting.cameraSwitchButtonRightMargin.string() {
            hasIntValue = true
        } else {
            hasIntValue = false
        }
    }
}

//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import Foundation

// Representation of some settings that can be customized on the overlay controller of the barcode picker.
struct OverlaySettings {
    var rotationWithDevice: Bool
    var restrictActiveScanningArea: Bool
    var beepEnabled: Bool
    var vibrateEnabled: Bool
    var torchEnabled: Bool
    var scanningHotSpotY: Float
    var scanAreaWidth: Float
    var scanAreaHeight: Float
    var viewfinderWidth: Float
    var viewfinderHeight: Float
    var viewfinderLandscapeWidth: Float
    var viewfinderLandscapeHeight: Float
    var guiStyle: String
    var torchButtonTopMargin: Float
    var torchButtonLeftMargin: Float
    var cameraSwitchVisibility: Int
    var cameraSwitchButtonTopMargin: Float
    var cameraSwitchButtonRightMargin: Float
    var timeoutDuration: Float
    var continuousScanning: Bool

    static func `default`() -> OverlaySettings {
        return OverlaySettings(
            rotationWithDevice: true,
            restrictActiveScanningArea: false,
            beepEnabled: true,
            vibrateEnabled: true,
            torchEnabled: true,
            scanningHotSpotY: 0.45,
            scanAreaWidth: 1.0,
            scanAreaHeight: 0.25,
            viewfinderWidth: 0.9,
            viewfinderHeight: 0.4,
            viewfinderLandscapeWidth: 0.6,
            viewfinderLandscapeHeight: 0.4,
            guiStyle: "Frame",
            torchButtonTopMargin: 15,
            torchButtonLeftMargin: 15,
            cameraSwitchVisibility: 0,
            cameraSwitchButtonTopMargin: 15,
            cameraSwitchButtonRightMargin: 15,
            timeoutDuration: 0.0,
            continuousScanning: false
        )
    }
}

//
//  SplitViewResult.swift
//  ExtendedSample
//
//  Created by Franciszek Gonciarz on 25.06.2018.
//  Copyright © 2018 Patrick Balestra. All rights reserved.
//

import Foundation

struct SplitViewResult {

    let barcode: String
    let symbology: String

}

//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

class StoryboardScanViewController: UIViewController {

    // This picker is added in the `StoryboardScan.storyboard`. Take a look at it for more information about how it works.
    @IBOutlet weak var barcodePicker: SBSBarcodePickerView!

    // view controller used to display the barcode results.
    lazy var barcodeResult: BarcodeResultViewController = {
        return BarcodeResultViewController.from(storyboard: .main)
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up the layout for presenting the barcode results.
        setUpLayout()

        // Set advanced settings that are unavailable in the Storyboard attribute inspector by code here.
        barcodePicker.viewController.setRelativeZoom(0.2)

        // Set the delegate to ourselves to be notified when a code is recognized.
        barcodePicker.scanDelegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        // The scanner is started automatically when loaded from a Storyboard, so no need to call startScanning() here.
        // barcodePicker.startScanning()
    }
}

extension StoryboardScanViewController: SBSScanDelegate {

    func barcodePicker(_ picker: SBSBarcodePicker, didScan session: SBSScanSession) {
        // Store the newly recognized codes.
        let codes = session.newlyRecognizedCodes

        // Pause scanning to present the newly found code.
        picker.pauseScanning()

        // Present view on main queue and pass the codes data.
        DispatchQueue.main.async {
            // Pass codes to show and set completion handler to resume scanning when overlay view is dismissed.
            self.barcodeResult.show(codes: codes) {
                picker.resumeScanning()
            }
        }
    }
}

extension StoryboardScanViewController {

    func setUpLayout() {
        addChild(barcodeResult)
        barcodeResult.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(barcodeResult.view)
        barcodeResult.view.constrainToEdges(of: view)
        barcodeResult.view.isHidden = true
        barcodeResult.didMove(toParent: self)
    }
}

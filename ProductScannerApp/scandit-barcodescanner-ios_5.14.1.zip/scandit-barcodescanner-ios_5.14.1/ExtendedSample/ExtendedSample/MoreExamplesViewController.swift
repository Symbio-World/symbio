//
// Copyright 2017 Scandit AG
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
// in compliance with the License. You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the
// License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
// express or implied. See the License for the specific language governing permissions and
// limitations under the License.
//

import UIKit

// Define all presentation modes.
enum PresentationType: String {
    case modal = "Modal Controller"
    case navigation = "Navigation Controller"
    case cropped = "Cropped View"
    case scaled = "Scaled View"
    case interfaceBuilder = "Interface Builder View"
    case split = "Split View"
}

class MoreExamplesViewController: UITableViewController {

    // Settings injected from `AppDelegate.swift` so they are easily accessible.
    var settings: ScanSettings!

    lazy var barcodeResult: BarcodeResultViewController = {
        return BarcodeResultViewController.from(storyboard: .main)
    }()

    lazy var overview: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.7)
        view.translatesAutoresizingMaskIntoConstraints = false
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissOverview))
        view.addGestureRecognizer(tap)
        return view
    }()

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        addOverview()

        // Remove the barcode result view controller in case it's not on a tabBar.
        if let tabBar = tabBarController?.selectedViewController, barcodeResult.parent != tabBar {
            barcodeResult.removeFromParent()
            barcodeResult.view.removeFromSuperview()
        }
    }

    func presentModalController() {
        // Initialize picker and apply settings.
        let picker = SBSBarcodePicker(settings: settings.scan)
        picker.apply(overlaySettings: settings.overlay)
        picker.overlayController.showToolBar(true)
        picker.scanDelegate = self
        picker.overlayController.cancelDelegate = self

        // Set up the barcode result UI.
        picker.addChild(barcodeResult)
        barcodeResult.view.translatesAutoresizingMaskIntoConstraints = false
        picker.view.addSubview(barcodeResult.view)
        barcodeResult.view.constrainToEdges(of: picker.view)
        barcodeResult.view.isHidden = true
        barcodeResult.didMove(toParent: picker)

        // Present the barcode picker.
        present(picker, animated: true)

        // Start scanning process.
        picker.startScanning()
    }

    func presentNavigationController() {
        // Initialize picker with the the preferred settings.
        let picker = SBSBarcodePicker(settings: settings.scan)
        // Apply overlay settings by using a convenience method defined in `SBSBarcodePicker+Utils.swift`.
        picker.apply(overlaySettings: settings.overlay)
        // Assign ourselves as the scan delegate.
        picker.scanDelegate = self

        // Set up the barcode result UI.
        picker.addChild(barcodeResult)
        barcodeResult.view.translatesAutoresizingMaskIntoConstraints = false
        picker.view.addSubview(barcodeResult.view)
        barcodeResult.view.constrainToEdges(of: picker.view)
        barcodeResult.view.isHidden = true
        barcodeResult.didMove(toParent: picker)

        // Push the picker on the navigation controller.
        navigationController?.pushViewController(picker, animated: true)

        // Start scanning process.
        picker.startScanning()
    }

    func presentCroppedView() {
        guard let selectedViewController = tabBarController?.selectedViewController else { return }

        // Initialize picker with the the preferred settings.
        let picker = SBSBarcodePicker(settings: settings.scan)
        // Apply overlay settings by using a convenience method defined in `SBSBarcodePicker+Utils.swift`.
        picker.apply(overlaySettings: settings.overlay)
        // Assign ourselves as the scan delegate.
        picker.scanDelegate = self

        // Set up the UI.
        addBarcodeResult()
        addChildViewControllerToTop(picker, to: selectedViewController, size: CGSize(width: view.frame.width, height: view.frame.height / 2))
        overview.isHidden = false

        // Start scanning process.
        picker.startScanning()
    }

    func presentScaledView() {
        guard let selectedViewController = tabBarController?.selectedViewController else { return }

        // Initialize picker with the the preferred settings.
        let picker = SBSBarcodePicker(settings: settings.scan)
        // Apply overlay settings by using a convenience method defined in `SBSBarcodePicker+Utils.swift`.
        picker.apply(overlaySettings: settings.overlay)
        // Assign ourselves as the scan delegate.
        picker.scanDelegate = self

        // Set up the UI.
        addBarcodeResult()
        addChildViewController(picker, to: selectedViewController, widthMultiplier: 0.6, heightMultiplier: 0.6)
        overview.isHidden = false

        // Start scanning process.
        picker.startScanning()
    }

    func presentInterfaceBuilder() {
        // Initialize the view controller and push it.
        let storyboardScan = StoryboardScanViewController.from(storyboard: .storyboardScan)
        navigationController?.pushViewController(storyboardScan, animated: true)
    }

    func presentSplitView() {
        let storyboard = UIStoryboard(name: "SplitView", bundle: nil)
        guard let splitViewViewController = storyboard.instantiateInitialViewController() else { return }
        navigationController?.pushViewController(splitViewViewController, animated: true)
    }

    // MARK: UITableViewDelegate

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        handleSelection(tableView, indexPath: indexPath)
    }
}

// MARK: - SBSScanDelegate

extension MoreExamplesViewController: SBSScanDelegate {
    // This delegate method of the SBSScanDelegate protocol needs to be implemented by
    // every app that uses the Scandit Barcode Scanner and this is where the custom application logic
    // goes. In the example below, we are presenting a custom view with the code information that can 
    // be dismissed with a simple touch.
    func barcodePicker(_ picker: SBSBarcodePicker, didScan session: SBSScanSession) {

        // Store the newly recognized codes.
        let codes = session.newlyRecognizedCodes

        // Pause scanning to present the newly found code.
        picker.pauseScanning()

        // Present view on main queue and pass the codes data.
        DispatchQueue.main.async {
            // Pass the codes to display them and set completion handler to resume scanning when the overlay view is dismissed.
            self.barcodeResult.show(codes: codes) {
                picker.resumeScanning()
            }
            // Make sure the barcode result is shown at the top.
            self.overview.bringSubviewToFront(self.barcodeResult.view)
        }
    }
}

// MARK: - SBSOverlayControllerDidCancelDelegate

extension MoreExamplesViewController: SBSOverlayControllerDidCancelDelegate {

    // Called when the "Cancel" button is pressed in the barcode picker toolbar. In this case, we simply dismiss the picker.
    func overlayController(_ overlayController: SBSOverlayController, didCancelWithStatus status: [AnyHashable : Any]?) {
        dismiss(animated: true)
    }
}

extension MoreExamplesViewController: UITabBarControllerDelegate {

    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        self.navigationController?.popToRootViewController(animated: false)
    }

    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if !overview.isHidden {
            dismissOverview()
        }
        let moreSelected = tabBarController.selectedViewController?.children.first is MoreExamplesViewController
        if moreSelected && viewController === tabBarController.selectedViewController {
            return false
        }
        return true
    }
}

// MARK: - UI Customizations

extension MoreExamplesViewController {

    @objc func dismissOverview() {
        // Hide the dark view.
        overview.isHidden = true

        // Clean up child view controllers for later reuse of the tabBar.
        self.navigationController?.children.forEach { vc in
            overview.subviews.forEach({ $0.removeFromSuperview()})
            if vc is SBSBarcodePicker || vc is BarcodeResultViewController {
                vc.view.removeFromSuperview()
                vc.removeFromParent()
            }
        }
    }

    // Add overview needed to present the barcode result.
    private func addOverview() {
        guard overview.superview == nil else { return }
        if let tabBar = tabBarController, let mainView = tabBar.selectedViewController?.view {
            mainView.addSubview(overview)
            overview.constrainToEdges(of: mainView)
            overview.isHidden = true
        }
    }

    private func addChildViewController(_ child: UIViewController, to parent: UIViewController, widthMultiplier: CGFloat, heightMultiplier: CGFloat) {
        parent.addChild(child)
        child.view.translatesAutoresizingMaskIntoConstraints = false
        overview.addSubview(child.view)
        child.didMove(toParent: parent)
        child.view.constrainToCenter(of: parent.view, widthMultiplier: widthMultiplier, heightMultiplier: heightMultiplier)
    }

    private func addChildViewControllerToTop(_ child: UIViewController, to parent: UIViewController, size: CGSize) {
        parent.addChild(child)
        child.view.translatesAutoresizingMaskIntoConstraints = false
        overview.addSubview(child.view)
        child.didMove(toParent: parent)
        child.view.constrainToTop(of: parent.view, widthMultiplier: 1.0, heightMultiplier: 0.5)
    }

    private func addBarcodeResult() {
        guard let tabBar = tabBarController, let mainView = tabBar.selectedViewController?.view else { return }
        tabBar.selectedViewController?.addChild(barcodeResult)
        barcodeResult.view.translatesAutoresizingMaskIntoConstraints = false
        overview.addSubview(barcodeResult.view)
        barcodeResult.view.constrainToEdges(of: mainView)
        barcodeResult.view.isHidden = true
        barcodeResult.didMove(toParent: tabBar.selectedViewController)
    }

    func handleSelection(_ tableView: UITableView, indexPath: IndexPath) {
        defer {
            tableView.deselectRow(at: indexPath, animated: true)
        }
        guard let cell = tableView.cellForRow(at: indexPath), let title = cell.textLabel?.text, let type = PresentationType(rawValue: title) else { return }
        switch type {
        case .modal:
            presentModalController()
        case .navigation:
            presentNavigationController()
        case .cropped:
            presentCroppedView()
        case .scaled:
            presentScaledView()
        case .interfaceBuilder:
            presentInterfaceBuilder()
        case .split:
            presentSplitView()
        }
    }
}

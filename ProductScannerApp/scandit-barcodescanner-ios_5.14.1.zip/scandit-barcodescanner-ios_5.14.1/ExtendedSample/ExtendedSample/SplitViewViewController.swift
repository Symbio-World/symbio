//
//  SplitViewViewController.swift
//  UseCases
//
//  Created by Franciszek Gonciarz on 26.03.2018.
//  Copyright © 2018 Scandit AG. All rights reserved.
//

import UIKit

protocol SplitViewResultViewControllerDelegate {

    func onResultsCleared()

}

class SplitViewViewController: UIViewController {

    enum ScanState {
        case scanning, paused, stopped
    }

    @IBOutlet weak var barcodePickerContainer: UIView!
    @IBOutlet weak var tableViewContainer: UIView!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var pickerHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var pausedStateOverlayView: UIView!
    @IBOutlet weak var tapToContinueButton: UIButton!

    var splitViewResultTableViewController: SplitViewResultTableViewController?
    private var scanningTimer: Timer?

    private var barcodePickerViewController: SBSBarcodePicker?
    private var symbologiesEnabled = Set<SBSSymbology>([.ean13, .upc12, .upce, .ean8, .code39, .code128]) // default symbologies enabled
    private var scanSettings: SBSScanSettings?

    // Scan View Height in percents relative to ViewController's height.
    private let scanViewHeight = 20.0
    // Determines if the beep sound will be played when the code will be found.
    private let beepEnabled = true
    // Duplicate code filter setting in seconds.
    private let duplicateFilterSeconds = 1
    // Scanner timeOut in seconds.
    private let timeOut = 10.0

    var scanState: ScanState = .stopped {
        didSet {
            switch scanState {
            case .scanning:
                startTimer()
            case .paused:
                break
            case .stopped:
                break
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Split View"

        configureButtons()

        setupBarcodeScanner(buildSettings())
        pickerHeightConstraint.constant = (view.frame.size.height * CGFloat(scanViewHeight)) / 100
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = false
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        restartScanning()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        pauseScanning()
    }

    private func configureButtons() {
        doneButton.setBackgroundImage(UIColor.standardBlue.image(), for: .normal)
        doneButton.tintColor = UIColor.standardBlue
        doneButton.clipsToBounds = true
        doneButton.layer.cornerRadius = 5
        clearButton.setBackgroundImage(UIColor.standardBlue.image(), for: .normal)
        clearButton.tintColor = UIColor.standardBlue
        clearButton.clipsToBounds = true
        clearButton.layer.cornerRadius = 5
        let leftBarButton = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.backBarButtonItem = leftBarButton
    }


    private func buildSettings() -> SBSScanSettings {
        let scanSettings = SBSScanSettings.default()
        scanSettings.areaSettingsPortrait = createAreaSettings(orientation: .portrait, hotspot: 0.5, wideCodesHeight: 0.05, squareCodesHeight: 0.35)
        scanSettings.areaSettingsLandscape = createAreaSettings(orientation: .landscape, hotspot: 0.5, wideCodesHeight: 0.05, squareCodesHeight: 0.35)

        for symbology in SBSSymbology.allCases {
            if (symbology == .twoDigitAddOn || symbology == .fiveDigitAddOn) && symbologiesEnabled.contains(symbology) {
                scanSettings.maxNumberOfCodesPerFrame = max(2, scanSettings.maxNumberOfCodesPerFrame)
            }
            scanSettings.setSymbology(symbology, enabled: symbologiesEnabled.contains(symbology))
        }
        barcodePickerViewController?.overlayController.setBeepEnabled(beepEnabled)
        scanSettings.codeDuplicateFilter = duplicateFilterSeconds >= 0 ? duplicateFilterSeconds * 1000 : duplicateFilterSeconds
        barcodePickerViewController?.overlayController.guiStyle = .laser

        return scanSettings
    }

    private func createAreaSettings(orientation: SBSOrientation, hotspot: Double, wideCodesHeight: Double, squareCodesHeight: Double) -> SBSScanAreaSettings {
        let scanAreaSettings = orientation == .portrait ? SBSScanAreaSettings.defaultPortrait() : SBSScanAreaSettings.defaultLandscape()
        scanAreaSettings.wideCodesLocationArea = CGRect(x: 0.0, y: 0.5 - (wideCodesHeight / 2), width: 1.0, height: wideCodesHeight)
        scanAreaSettings.squareCodesLocationArea = CGRect(x: 0.4, y: 0.5 - (squareCodesHeight / 2), width: 0.2, height: squareCodesHeight)
        scanAreaSettings.wideCodesLocationConstraint = .restrict
        scanAreaSettings.squareCodesLocationConstraint = .restrict
        return scanAreaSettings
    }

    private func setupBarcodeScanner(_ settings: SBSScanSettings) {
        self.scanSettings = settings

        barcodePickerViewController = SBSBarcodePicker(settings: settings)

        guard let pickerViewController = barcodePickerViewController else {
            fatalError("SBSBarcodePicker failed to initialize")
        }

        pickerViewController.scanDelegate = self

        pickerViewController.overlayController.showToolBar(false)
        pickerViewController.overlayController.setCameraSwitchVisibility(.onTablet)
        pickerViewController.overlayController.guiStyle = .laser
        pickerViewController.overlayController.setTextRecognitionSwitchVisible(false)

        addChild(pickerViewController)
        pickerViewController.view.translatesAutoresizingMaskIntoConstraints = false
        barcodePickerContainer.addSubview(pickerViewController.view)
        pickerViewController.view.constrainToEdges(of: barcodePickerContainer)
        pickerViewController.didMove(toParent: self)
        startScanning()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EmbedSplitViewResultTableViewController" {
            splitViewResultTableViewController = segue.destination as? SplitViewResultTableViewController
        }
    }

    func startTimer() {
        scanningTimer?.invalidate()
        scanningTimer = nil
        scanningTimer = Timer.scheduledTimer(timeInterval: timeOut, target: self, selector: #selector(pauseScanning), userInfo: nil, repeats: false)
    }

    @objc private func pauseScanning() {
        DispatchQueue.main.async { [weak self] in
            self?.barcodePickerViewController?.pauseScanning()
            self?.scanState = .paused
            self?.pausedStateOverlayView.isHidden = false
            self?.tapToContinueButton.isHidden = false
        }
    }

    @objc private func startScanning() {
        DispatchQueue.main.async { [weak self] in
            self?.barcodePickerViewController?.startScanning()
            self?.scanState = .scanning
            self?.pausedStateOverlayView.isHidden = true
            self?.tapToContinueButton.isHidden = true
        }
    }

    @objc private func restartScanning() {
        DispatchQueue.main.async { [weak self] in
            self?.barcodePickerViewController?.resumeScanning()
            self?.scanState = .scanning
            self?.pausedStateOverlayView.isHidden = true
            self?.tapToContinueButton.isHidden = true
        }
    }

    @IBAction func tapToContinueButtonPressed(_ sender: Any) {
        restartScanning()
    }

    @IBAction func clearButtonPressed(_ sender: Any) {
        splitViewResultTableViewController?.clearResults()
    }

    @IBAction func doneButtonPressed(_ sender: Any) {
        if let splitViewResultViewController = UIStoryboard.init(name: "SplitView", bundle: nil).instantiateViewController(withIdentifier: "SplitViewResultViewController") as? SplitViewResultViewController, let results = splitViewResultTableViewController?.splitViewResults {
            splitViewResultViewController.splitViewResults = results
            splitViewResultViewController.splitViewResultViewControllerDelegate = self
            navigationController?.pushViewController(splitViewResultViewController, animated: true)
        }
    }

}

extension SplitViewViewController: SBSScanDelegate {

    //MARK: SBSScanDelegate

    func barcodePicker(_ picker: SBSBarcodePicker, didScan session: SBSScanSession) {
        let codes = session.newlyRecognizedCodes
        if codes.count == 1 && (codes[0].symbology == .fiveDigitAddOn || codes[0].symbology == .twoDigitAddOn) {
            // Just found an add-on, let's keep going
            return
        }

        DispatchQueue.main.async { [weak self] in
            self?.startTimer()
            for code in codes {
                guard let barcode = code.data else { continue }
                self?.splitViewResultTableViewController?.add(result: SplitViewResult(barcode: barcode, symbology: code.symbologyName))
            }
        }
    }
}

extension SplitViewViewController: SplitViewResultViewControllerDelegate {

    func onResultsCleared() {
        splitViewResultTableViewController?.clearResults()
    }

}
